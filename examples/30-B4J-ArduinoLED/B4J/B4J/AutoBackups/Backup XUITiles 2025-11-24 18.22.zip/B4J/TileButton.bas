﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=10.3
@EndOfDesignText@
#Region Class Header
' ================================================================
' File:     	TileButton.bas
' Brief:    	Tile that behaves like a button (clickable).
'           	Supports Normal, Warning, Error, Dimmed styles.
' Properties:	All ISA-101 style properties are defined in TileUtils.
'				The designer properties are not used.
'				TitleText - Base properties set from Label property.
'							Text set from designer property TitleText.
'				StateText - Base properties set from Label property.
'							Text set from designer property Text (Label)
'
' Modes:		This TileButton is a single CustomView with multiple behaviors:
'				Normal Button - Set text As normal Label
'					TileButton1.Text = "Start"
'				Toggle Button - Using FA toggle icons
'					TileButton1.Text = IIf(newState, Chr(0xF205), Chr(0xF204))
'				Switch - Use “ON / OFF”
'					TileButton1.Text = IIf(newState, "ON", "OFF")
'				Light Bulb Control
'					TileButton1.Text = IIf(newState, Chr(0xF0EB), Chr(0xF111))
'				Lock/Unlock
'					TileButton1.Text = IIf(locked, Chr(0xF023), Chr(0xF09C)) 
'				Open/Close
'					TileButton1.Text = IIf(isOpen, Chr(0xF2C2), Chr(0xF2C1))
'
' Example Toggle Button with FontAwesome font
' Private TileButtonToggle As TileButton
' ' Set labelstate font, state false and click to set the initial icon off
'	TileButtonToggle.SetStateFontFontAwesome
'	TileButtonToggle.State = False
'	TileButtonToggle_Click
' ' Button Click Event
' Private Sub TileButtonToggle_Click
'	TileButtonToggle.StateText = IIf(TileButtonToggle.State, Chr(0xF205), Chr(0xF204)) ' FA toggle-on / toggle-off
'	TileEventViewer1.Insert($"[TileButtonToggle] state=${TileButtonToggle.State}"$, TileUtils.LOG_LEVEL_INFO)
' End Sub
'
' Example Callback: UI follows actual device state
' ' Button with text change
' Private Sub TileButton1_Click
' 	Dim state As Boolean = Not(DevYellowLed.Get)
'	DevYellowLed.Set(state)
'	TileButton1.Text = IIf(state, "ON", "OFF")
'	TileButton1.SetStateColor(state)
' End Sub
' ================================================================
#End Region

' Designer Properties
#DesignerProperty: Key: TitleText, DisplayName: Title, FieldType: String, DefaultValue: Title
#DesignerProperty: Key: StateText, DisplayName: State, FieldType: String, DefaultValue: Button, Description: Use designer property Label
#DesignerProperty: Key: TypeStyle, DisplayName: Button Style, FieldType: String, List: Normal|Warning|Alarm|Dimmed, DefaultValue: Normal

' Events
#Event: Click

Sub Class_Globals
	' Base
	Public mBase As B4XView
	Public mLbl As B4XView
	Public Tag As Object

	' Events
	Private mEventName As String
	Private mCallBack As Object

	' UI
	Private xui As XUI
	Private LabelTitle As B4XView
	Private LabelState As B4XView

	' Fixed properties
	Private mIsPressed As Boolean = False			'ignore
	Private mState As Boolean = False
End Sub

Public Sub Initialize (Callback As Object, EventName As String)
	mEventName = EventName
	mCallBack = Callback
End Sub

Public Sub DesignerCreateView (Base As Object, Lbl As Label, Props As Map)
	mBase = Base
	mLbl = Lbl
	Tag = mBase.Tag
	mBase.Tag = Me
	CallSubDelayed2(Me, "AfterLoadLayout", Props)
End Sub

Private Sub AfterLoadLayout(Props As Map)	'ignore
	mBase.LoadLayout("TileButton")
	LabelTitle.Text = Props.Get("TitleText")
	LabelState.Text = Props.Get("StateText")
	ApplyStyle(Props.Get("TypeStyle"))
	Base_Resize(mBase.Width, mBase.Height)
End Sub

Private Sub Base_Resize(Width As Double, Height As Double)
	If Not(LabelTitle.IsInitialized) Or Not(LabelState.IsInitialized) Then Return

	Dim pad As Int = TileUtils.TILE_BORDER_WIDTH + 4dip
	
	LabelTitle.SetLayoutAnimated(0, pad, pad, Width - pad*2, Height * 0.25)
	LabelState.SetLayoutAnimated(0, pad, Height*0.25, Width - pad*2, Height*0.50)
End Sub

' ================================================================
' Getter / Setter
' ================================================================
Public Sub setTitleText(value As String)
	LabelTitle.Text = value
End Sub
Public Sub getTitleText As String
	Return LabelTitle.Text
End Sub

Public Sub setTitleTextSize(value As Int)
	LabelTitle.TextSize = value
End Sub
Public Sub getTitleTextSize As Int
	Return LabelTitle.TextSize
End Sub

Public Sub setTitleTextColor(value As Int)
	LabelTitle.TextColor = value
End Sub
Public Sub getTitleTextColor As Int
	Return LabelTitle.TextColor
End Sub

Public Sub setStateText(value As String)
	LabelState.Text = value
End Sub
Public Sub getStateText As String
	Return LabelState.Text
End Sub

Public Sub SetStateOnOff(state As Boolean)
	TileUtils.ApplyStyleStateOnOff(mBase, LabelState, state)
End Sub

Public Sub setStateTextSize(value As Int)
	LabelState.TextSize = value
End Sub
Public Sub getStateTextSize As Int
	Return LabelState.TextSize
End Sub

Public Sub setStateTextColor(value As Int)
	LabelState.TextColor = value
End Sub
Public Sub getStateTextColor As Int
	Return LabelState.TextColor
End Sub

' Get or set the state of the button.
Public Sub setState(state As Boolean)
	mState = state
End Sub
Public Sub getState As Boolean
	Return mState
End Sub

Public Sub SetStateFontFontAwesome
	LabelState.Font = xui.CreateFontAwesome(TileUtils.TEXT_SIZE_ICON)
End Sub

Public Sub SetStateFontDefault
	LabelState.Font = xui.CreateDefaultFont(TileUtils.TEXT_SIZE_STATE)
End Sub

Public Sub SetStateColor(success As Boolean)
	TileUtils.ApplyStyleStateOnOff(mBase, LabelState, success)
End Sub

Public Sub setBackgroundColor(clr As Int)
	mBase.Color = clr
End Sub

Public Sub getBackgroundColor As Int
	Return mBase.Color
End Sub

Public Sub setEnabled(enabled As Boolean)
	mBase.Enabled = enabled
	If mBase.enabled Then
		mBase.Alpha = 1
	Else
		mBase.Alpha = 0.4
	End If
End Sub

Public Sub getEnabled As Boolean
	Return mBase.Enabled
End Sub

Public Sub SetInfo(text As String)
	setStateText(text)
	setBackgroundColor(TileUtils.COLOR_BACKGROUND_TILE_DEFAULT)   ' neutral gray
	setStateTextColor(TileUtils.COLOR_TEXT_PRIMARY)
End Sub

Public Sub SetWarning(text As String)
	setStateText(text)
	setBackgroundColor(TileUtils.COLOR_STATUS_WARNING)  ' ISA Amber
	setStateTextColor(TileUtils.TILE_COLOR_WARNING_TEXT)  ' black text for readability
End Sub

Public Sub SetError(text As String)
	setStateText(text)
	setBackgroundColor(TileUtils.COLOR_STATUS_ALARM_HI)  ' ISA Red
	setStateTextColor(TileUtils.TILE_COLOR_ALARM_TEXT)  ' white text for contrast
End Sub

' ================================================================
' Internal Graphics
' ================================================================

' ================================================================
' Mouse Events (Button Behavior)
' ================================================================

Private Sub LabelState_MouseEntered (EventData As MouseEvent)
    If mBase.Enabled Then mBase.Alpha = 0.85
End Sub

Private Sub LabelState_MouseClicked(EventData As MouseEvent)
	mState = Not(mState)
	If SubExists(mCallBack, mEventName & "_Click") Then
		CallSub(mCallBack, mEventName & "_Click")
	End If
End Sub

Private Sub LabelState_MousePressed (EventData As MouseEvent)
	mIsPressed = True
	mBase.Alpha = 0.7   ' visual feedback
End Sub

Private Sub LabelState_MouseReleased (EventData As MouseEvent)
	mIsPressed = False
	mBase.Alpha = 1.0
End Sub

Private Sub LabelTitle_MouseEntered (EventData As MouseEvent)
	LabelState_MouseEntered(EventData)
End Sub

Private Sub LabelTitle_MouseClicked (EventData As MouseEvent)
	LabelState_MouseClicked(EventData)
End Sub

Private Sub LabelTitle_MousePressed (EventData As MouseEvent)
	LabelState_MousePressed(EventData)
End Sub

Private Sub LabelTitle_MouseReleased (EventData As MouseEvent)
	LabelState_MouseReleased(EventData)
End Sub



' ================================================================
' TILE STYLING
' ================================================================
#Region Tile Styling
Public Sub ApplyStyle(tilestate As String)

	' --- Consistent Title Style ---
	LabelTitle.TextColor = TileUtils.COLOR_TEXT_SECONDARY
	LabelTitle.TextSize = TileUtils.TEXT_SIZE_TITLE

	' Convert designer string → tile state constant
	Dim state As Int = TileUtils.StateStyleToState(tilestate)

	' --- Apply State Colors ---
	Select state

		Case TileUtils.TILE_STATE_NORMAL
			LabelState.TextSize = TileUtils.TEXT_SIZE_LABEL
			LabelState.TextColor = TileUtils.TILE_COLOR_NORMAL_TEXT
			mBase.Color = TileUtils.TILE_COLOR_NORMAL_BACKGROUND

		Case TileUtils.TILE_STATE_WARNING
			LabelState.TextSize = TileUtils.TEXT_SIZE_LABEL
			LabelState.TextColor = TileUtils.TILE_COLOR_WARNING_TEXT
			mBase.Color = TileUtils.TILE_COLOR_WARNING_BACKGROUND

		Case TileUtils.TILE_STATE_ALARM
			LabelState.TextSize = TileUtils.TEXT_SIZE_LABEL + 1dip    'slightly larger for readability
			LabelState.TextColor = TileUtils.TILE_COLOR_ALARM_TEXT
			mBase.Color = TileUtils.TILE_COLOR_ALARM_BACKGROUND

		Case TileUtils.TILE_STATE_DISABLED
			LabelState.TextSize = TileUtils.TEXT_SIZE_LABEL
			LabelState.TextColor = TileUtils.TILE_COLOR_DISABLED_TEXT
			mBase.Color = TileUtils.TILE_COLOR_DISABLED_BACKGROUND
	End Select

	' --- Standard Tile Border (ISA-101 compliant) ---
	mBase.SetColorAndBorder( _
        mBase.Color, _
        TileUtils.TILE_BORDER_WIDTH, _
        TileUtils.COLOR_BORDER_DEFAULT, _
        TileUtils.TILE_BORDER_RADIUS)

End Sub
#End Region
