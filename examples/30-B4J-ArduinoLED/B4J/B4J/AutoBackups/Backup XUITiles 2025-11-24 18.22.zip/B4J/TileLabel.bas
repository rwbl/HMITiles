﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=10.3
@EndOfDesignText@
#Region Class Header
' ================================================================
' File: 	TileLabel.bas
' Brief:	Tile with a single label centered.
'			Style can be set to Normal, Warning, Alarm or Dimmed.
' Style:	ISA-101 requires:
'			- High-contrast foreground
'			- Alarm = red background + white text
'			- Warning = amber background + black text
'			- Normal = light background + dark text
'			- Dimmed = reduced contrast but still readable
'			| State    | Background | Text      | Readability           |
'			| -------- | ---------- | --------- | --------------------- |
'			| Normal   | light gray | dark gray | ✔ good                |
'			| Warning  | amber      | black     | ✔ high contrast       |
'			| Alarm    | red        | white     | ✔ very high contrast  |
'			| Disabled | gray       | soft gray | ✔ subtle but readable |
' Hints: 	Tile can not be resized after form loaded.
' 			DesignerProperty FieldType - One of the following values (case insensitive): String, Int, Float, Boolean or Color.
' Layout:
' +-----+
' |+---+|
' || T ||
' |+---+|
' +-----+
' ================================================================
#End Region

' Views
#DesignerProperty: Key: LabelText, DisplayName: Text, FieldType: String, DefaultValue: Label
#DesignerProperty: Key: TypeStyle, DisplayName: Type Style, FieldType: String, List: Normal|Warning|Alarm|Dimmed, DefaultValue: Normal

' Events
#Event: Click(EventData As MouseEvent)

Sub Class_Globals
	' Base
	Public mBase As B4XView
	Public mLbl As B4XView
	Public Tag As Object

	' Events
	Private mEventName As String 'ignore
	Private mCallBack As Object 'ignore
	
	' XUI
	Private xui As XUI 'ignore
	Private LabelText As B4XView

	' Properties (designer)
	Private mEnabled As Boolean = True

	' Properties (fixed)
End Sub

Public Sub Initialize (Callback As Object, EventName As String)
	mEventName = EventName
	mCallBack = Callback
End Sub

'Base type must be Object
Public Sub DesignerCreateView (Base As Object, Lbl As Label, Props As Map)
	mBase = Base
	mLbl = Lbl
	Tag = mBase.Tag
	mBase.Tag = Me
	' Load the customview layout(s) via CallSubDelayed.
	CallSubDelayed2(Me, "AfterLoadLayout", Props)
End Sub

Sub AfterLoadLayout(Props As Map)	'ignore
	mBase.LoadLayout("TileLabel")
	LabelText.Text = Props.Get("LabelText")
	ApplyStyle(Props.Get("TypeStyle"))
	Base_Resize(mBase.Width, mBase.Height)
End Sub

Private Sub Base_Resize (Width As Double, Height As Double)
	' Only resize if view is initialized
	If Not(LabelText.IsInitialized) Then Return

	Dim offset As Int = TileUtils.TILE_BORDER_WIDTH
	LabelText.SetLayoutAnimated(0, offset, offset, Width - offset*2, Height - offset*2)
End Sub

' Getter/Setter

Public Sub setTileColor(value As Int)
	mBase.Color = value
	LabelText.Color = mBase.Color
End Sub
Public Sub getTileColor As Int
	Return mBase.Color
End Sub

Public Sub setTextColor(value As Int)
	LabelText.TextColor = value
End Sub
Public Sub getTextColor As Int
	Return LabelText.TextColor
End Sub

Public Sub setText(text As String)
	LabelText.Text = text
End Sub
Public Sub getText As String
	Return LabelText.Text
End Sub

Public Sub setTextSize(value As Int)
	LabelText.TextSize = value
End Sub
Public Sub getTextSize As Int
	Return LabelText.TextSize
End Sub

Public Sub setTextStyleBold(value As Boolean)
	TileUtils.SetStyleBold(LabelText, value)
End Sub
Public Sub getTextStyleBold As Boolean
	Return CSSUtils.GetStyleProperty(LabelText, "-fx-font-weight") == "bold"
End Sub

Public Sub setEnabled(enabled As Boolean)
	mBase.Enabled = enabled
	mEnabled = mBase.Enabled
	If enabled Then
		mBase.Alpha = 1
	Else
		mBase.Alpha = 0.4
	End If
End Sub

Public Sub getEnabled As Boolean
	Return mEnabled
End Sub

Public Sub SetStateColor(success As Boolean)
	TileUtils.ApplyStyleStateOnOff(mBase, LabelText, success)
End Sub

Private Sub LabelText_MouseClicked (EventData As MouseEvent)
	If SubExists(mCallBack, mEventName & "_Click") Then
		CallSub2(mCallBack, mEventName & "_Click", EventData)
	End If
End Sub

' ================================================================
' TILE STYLING
' ================================================================
#Region Tile Styling
' ApplyStyleLabel
' For all tiles the title style are consistent
' Parameters:
'	view B4XView - label
Public Sub ApplyStyle(tilestate As String)

	Dim s As String = TileUtils.StateStyleToState(tilestate)

	' Default text properties
	LabelText.TextSize = TileUtils.TEXT_SIZE_TITLE
	LabelText.TextColor = TileUtils.COLOR_TEXT_PRIMARY

	Select s
		Case TileUtils.TILE_STATE_NORMAL
			mBase.Color = TileUtils.TILE_COLOR_NORMAL_BACKGROUND
			LabelText.TextColor = TileUtils.COLOR_TEXT_PRIMARY   'dark gray

		Case TileUtils.TILE_STATE_WARNING
			mBase.Color = TileUtils.TILE_COLOR_WARNING_BACKGROUND
			LabelText.TextColor = 0xFF000000   'black (max contrast)

		Case TileUtils.TILE_STATE_ALARM
			mBase.Color = TileUtils.TILE_COLOR_ALARM_BACKGROUND
			LabelText.TextColor = 0xFFFFFFFF   'white (ISA-101 compliant)

		Case TileUtils.TILE_STATE_DISABLED
			mBase.Color = TileUtils.TILE_COLOR_DISABLED_BACKGROUND
			LabelText.TextColor = TileUtils.COLOR_TEXT_DISABLED  'soft gray
	End Select

	' Border styling
	mBase.SetColorAndBorder( _
        mBase.Color, _
        TileUtils.TILE_BORDER_WIDTH, _
        mBase.Color, _
        TileUtils.TILE_BORDER_RADIUS)

End Sub
#End Region
