﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=10.3
@EndOfDesignText@
#Region Class Header
' ================================================================
' File: 	TileSlider.bas
' Brief:	Tile to select RGB values (0..255), using seekbar with live color preview.
' Hints: 	Tile can not be resized after form loaded.
' Layout:	Horizontal sliders are preferred For routine setpoint adjustments. 
'			This Is the ISA-101-aligned default
'			Use horizontal when:
'			- The operator adjusts values frequently
'			- The value scales left→right (normal expectation)
'			- Space Is limited vertically
'			- The tile-based UI grid flows horizontally (your Case)
'			Why?
'			Operators naturally map “increase” To → right.
'			ISA-101 emphasizes natural mapping And operator expectation.
'
'			+----------------------------------+
'			|  Title (e.g.: Setpoint)          |
'			|  Current: 42 %                   |
'			|                                  |
'			|  [=====●------------]            |
'			|                                  |
'			|  Min   0%     Max  100%          |
'			+----------------------------------+
' ================================================================
#End Region

' Properties
#DesignerProperty: Key: TitleText, DisplayName: Title, FieldType: String, DefaultValue: Title
#DesignerProperty: Key: Value, DisplayName: Value, FieldType: Int, DefaultValue: 0
#DesignerProperty: Key: ValueMin, DisplayName: Min Value, FieldType: Int, DefaultValue: 0
#DesignerProperty: Key: ValueMax, DisplayName: Max Value, FieldType: Int, DefaultValue: 100
#DesignerProperty: Key: TouchStateChanged, DisplayName: Use TouchState, FieldType: Boolean, DefaultValue: False, Description: Use touchstate released to trigger event instead every value change.

' Events
#Event: ValueChanged (value As Int)

Sub Class_Globals
	' Events
	Private mEventName As String
	Private mCallBack As Object

	' Base
	Public mBase As B4XView
	Public mLbl As B4XView
	Public Tag As Object

	' UI
	Private xui As XUI
	Private LabelTitle As B4XView
	Private LabelValue As B4XView
	Private B4XSeekBarValue As B4XSeekBarEx
	Private LabelMinMax As B4XView

	' Designer properties
	Private mValue As Int
	Private mValueMin As Int
	Private mValueMax As Int
	Private mTouchStateChanged As Boolean
End Sub

Public Sub Initialize (Callback As Object, EventName As String)
	mCallBack = Callback
	mEventName = EventName
End Sub

Public Sub DesignerCreateView (Base As Object, Lbl As Label, Props As Map)
	mBase = Base
	mLbl = Lbl
	Tag = mBase.Tag
	mBase.Tag = Me
	CallSubDelayed2(Me, "AfterLoadLayout", Props)
End Sub

Sub AfterLoadLayout(Props As Map)	'ignore
	mBase.LoadLayout("TileSlider")

	' Set local class vars
	mValue 			= Props.Get("Value")
	mValueMin 		= Props.Get("ValueMin")
	mValueMax 		= Props.Get("ValueMax")
	mTouchStateChanged = Props.Get("TouchStateChanged")

	' Default values
	B4XSeekBarValue.Value = mValue
	B4XSeekBarValue.MinValue = mValueMin
	B4XSeekBarValue.MaxValue = mValueMax

	' Set Labels
	LabelTitle.Text = Props.Get("TitleText")
	LabelValue.Text = $"Current: ${mValue}"$
	LabelMinMax.Text = $"Min: ${mValueMin} Max: ${mValueMax}"$

	ApplyStyle
	Base_Resize(mBase.Width, mBase.Height)
End Sub

Private Sub Base_Resize (Width As Double, Height As Double)
	HorizontalBaseResize (Width, Height)
End Sub

#Region HorizontalBaseResize
Private Sub HorizontalBaseResize(Width As Double, Height As Double)
	If Not(B4XSeekBarValue.IsInitialized) Then Return

	Dim pad As Int = TileUtils.TILE_BORDER_WIDTH + 4dip
	Dim l As Int = pad
	Dim y As Int = pad
	Dim w As Int = Width - pad * 2

	' --- compute heights proportionally ---
	Dim availHeight As Double = Height - pad * 2
	Dim titleH As Double = availHeight * 0.2
	Dim valueH As Double = availHeight * 0.15
	Dim sliderH As Double = availHeight * 0.5
	Dim minMaxH As Double = availHeight * 0.15

	' --- Title ---
	LabelTitle.SetLayoutAnimated(0, l, y, w, titleH)
	y = y + titleH

	' --- Value ---
	LabelValue.SetLayoutAnimated(0, l, y, w, valueH)
	y = y + valueH

	' --- Slider ---
	B4XSeekBarValue.mBase.SetLayoutAnimated(0, l, y, w, sliderH)
	y = y + sliderH

	' --- Min / Max ---
	LabelMinMax.SetLayoutAnimated(0, l, y, w, minMaxH)
    
	UpdateUI
End Sub
#End Region

Private Sub UpdateUI
	mValue = B4XSeekBarValue.Value
	LabelValue.Text = $"Current: ${mValue}"$
	LabelMinMax.Text = $"Min: ${mValueMin} Max: ${mValueMax}"$
	If Not(mTouchStateChanged) Then
		ValueChanged(mValue)
	End If
End Sub

Private Sub ApplyStyle
	mBase.Color = TileUtils.TILE_COLOR_NORMAL_BACKGROUND
	mBase.SetColorAndBorder(TileUtils.COLOR_BACKGROUND_TILE_DEFAULT, _
						    TileUtils.TILE_BORDER_WIDTH, _ 
						    TileUtils.COLOR_STATE_ON_BORDER, _
						    TileUtils.TILE_BORDER_RADIUS)

	LabelTitle.TextColor = TileUtils.COLOR_TEXT_SECONDARY
	LabelTitle.TextSize = TileUtils.TEXT_SIZE_TITLE
	LabelValue.TextColor = TileUtils.COLOR_TEXT_SECONDARY
	LabelValue.TextSize = TileUtils.TEXT_SIZE_SMALL
	LabelMinMax.TextColor = TileUtils.COLOR_TEXT_SECONDARY
	LabelMinMax.TextSize = TileUtils.TEXT_SIZE_TINY
	
	B4XSeekBarValue.Color1 = TileUtils.COLOR_SLIDER_TRACK
	B4XSeekBarValue.Color2 = TileUtils.COLOR_SLIDER_ACTIVE
	B4XSeekBarValue.ThumbColor = TileUtils.COLOR_SLIDER_KNOB
	B4XSeekBarValue.TickValColor = TileUtils.COLOR_SLIDER_LABEL_TEXT
End Sub

' Properties
Public Sub setEnabled(enabled As Boolean)
	mBase.Enabled = enabled
	If mBase.enabled Then
		mBase.Alpha = 1
	Else
		mBase.Alpha = 0.4
	End If
End Sub

Public Sub getEnabled As Boolean
	Return mBase.Enabled
End Sub

' Seekbar value changes
' Update UI and trigger event.
Private Sub B4XSeekBarValue_ValueChanged (Value As Int)
	UpdateUI
End Sub

' Event triggered by seekbar value changes
Private Sub ValueChanged(value As Int)
	mValue = value
	If SubExists(mCallBack, mEventName & "_ValueChanged") Then
		CallSub2(mCallBack, mEventName & "_ValueChanged", value)
	End If
End Sub

Private Sub B4XSeekBarValue_TouchStateChanged (Pressed As Boolean)
	If mTouchStateChanged Then
		If Not(Pressed) Then
			ValueChanged(mValue)
		End If
	End If
End Sub

