﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=10.3
@EndOfDesignText@
#Region Class Header
' ================================================================
' File:     TileDigitalClock.bas
' Brief:    A digital clock tile (HH:MM or HH:MM:SS)
' Notes:    Very similar to TileLabel, but automatically updates
' ================================================================
#End Region

#DesignerProperty: Key: ShowSeconds, DisplayName: Show Seconds, FieldType: Boolean, DefaultValue: False
#DesignerProperty: Key: BlinkColon, DisplayName: Blink Colon, FieldType: Boolean, DefaultValue: False
#DesignerProperty: Key: TypeStyle, DisplayName: Tile Style, FieldType: String, List: Normal|Warning|Alarm|Dimmed, DefaultValue: Normal

#Event: Click(EventData As MouseEvent)

Sub Class_Globals
	Private xui As XUI

	Public mBase As B4XView
	Private mLbl As B4XView
	Public Tag As Object

	Private mEventName As String
	Private mCallBack As Object

	Private LabelText As B4XView

	Private mTimerClock As Timer
	Private mClockBlink As Boolean
	Private mShowSec As Boolean
	Private mDoBlink As Boolean
End Sub

Public Sub Initialize(Callback As Object, EventName As String)
	mEventName = EventName
	mCallBack = Callback
	mTimerClock.Initialize("TimerClock", 1000)
End Sub

Public Sub DesignerCreateView(Base As Object, Lbl As Label, Props As Map)
	mBase = Base
	mLbl = Lbl
	Tag = mBase.Tag
	mBase.Tag = Me

	' Load the customview layout(s) via CallSubDelayed.
	CallSubDelayed2(Me, "AfterLoadLayout", Props)
End Sub

Sub AfterLoadLayout(Props As Map)
	mBase.LoadLayout("TileLabel")

	' Get the designer properties
	mShowSec = Props.Get("ShowSeconds")
	mDoBlink = Props.Get("BlinkColon")

	ApplyStyle

	' Resize to get the sizing right
	Base_Resize(mBase.Width, mBase.Height)
	
	StartClock
End Sub

Public Sub Base_Resize (Width As Double, Height As Double)
	mLbl.SetLayoutAnimated(0, 0, 0, Width, Height)
End Sub

' ================================================================
' TILE STYLING
' ================================================================
#Region Tile Styling
' ApplyStyleLabel
' For all tiles the title style are consistent
' Parameters:
'	view B4XView - label
Public Sub ApplyStyle
	LabelText.TextColor = TileUtils.COLOR_TEXT_SECONDARY
	LabelText.TextSize = TileUtils.TEXT_SIZE_TITLE
	mBase.Color = TileUtils.TILE_COLOR_NORMAL_BACKGROUND
	mBase.SetColorAndBorder(TileUtils.COLOR_BACKGROUND_TILE_DEFAULT, _
							TileUtils.TILE_BORDER_WIDTH, _ 
							TileUtils.COLOR_STATE_ON_BORDER, _
							TileUtils.TILE_BORDER_RADIUS)
End Sub
#End Region

#Region Clock
Private Sub StartClock
	mTimerClock.Enabled = True
End Sub

Private Sub TimerClock_Tick
	UpdateClock
End Sub

Private Sub UpdateClock
	Dim now As Long = DateTime.Now
	Dim h As Int = DateTime.GetHour(now)
	Dim m As Int = DateTime.GetMinute(now)
	Dim s As Int = DateTime.GetSecond(now)

	Dim colon As String = ":"
	If mDoBlink Then
		If mClockBlink = False Then colon = " "
		mClockBlink = Not(mClockBlink)
	End If

	Dim txt As String
	If mShowSec Then
		txt = NumberFormat2(h, 2, 0, 0, False) & colon & NumberFormat2(m, 2, 0, 0, False) & colon & NumberFormat2(s, 2, 0, 0, False)
	Else
		txt = NumberFormat2(h, 2, 0, 0, False) & colon & NumberFormat2(m, 2, 0, 0, False)
	End If

	' mLbl.Text = txt
	LabelText.Text = txt
End Sub

#End Region

Private Sub LabelText_MouseClicked (EventData As MouseEvent)
	If SubExists(mCallBack, mEventName & "_Click") Then
		CallSub2(mCallBack, mEventName & "_Click", EventData)
	End If
End Sub

