﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=9.85
@EndOfDesignText@
' ================================================================
' File:			XUITiles
' Brief:		Development program for the XUITiles B4X library.
' Date:			2025-11-24
' Author:		Robert W.B. Linn (c) 2025 MIT
' Description:	This library provides tile views following the ISA-101 standard.
' DependsOn:	B4XSeekBarEx.b4xlib, XUI Views, ByteConverter
' Notes:		- Ctrl + click to export as zip: ide://run?File=%B4X%\Zipper.jar&Args=Project.zip
' 				- See the list of page related events in the B4XPagesManager object. The event name is B4XPage.
' ================================================================

#Region Shared Files
#CustomBuildAction: folders ready, %WINDIR%\System32\Robocopy.exe,"..\..\Shared Files" "..\Files"
'Ctrl + click to sync files: ide://run?file=%WINDIR%\System32\Robocopy.exe&args=..\..\Shared+Files&args=..\Files&FilesSync=True
#End Region

Sub Class_Globals
	Private VERSION As String = "XUITiles v20251124"
	Private ABOUT As String = $"${VERSION} (c) 2025 Robert W.B. Linn - MIT"$
	
	' UI
	Private xui As XUI
	Private Root As B4XView
	Private LabelAbout As B4XView
	' UI Tiles
	Private TileButtonOnOff As TileButton
	Private TileButtonToggle As TileButton
	Private TileEventViewer1 As TileEventViewer
	Private TileButtonAlarm As TileButton
	Private TileLevel1 As TileLevel
End Sub

Public Sub Initialize
	B4XPages.GetManager.LogEvents = True
End Sub

'This event will be called once, before the page becomes visible.
Private Sub B4XPage_Created (Root1 As B4XView)
	Root = Root1
	Root.LoadLayout("MainPage")

	' UI  additional settings
	Root.Color = TileUtils.COLOR_BACKGROUND_SCREEN
	B4XPages.SetTitle(Me, VERSION)
	B4XPages.GetNativeParent(Me).Resizable = False
	LabelAbout.Text = ABOUT
	
	' Eventviewer - ensure to set sleep prior calling customviews
	Sleep(1)
	TileEventViewer1.Insert(VERSION, TileUtils.EVENT_LEVEL_INFO)
	' OnOff Button
	TileButtonOnOff.State = False
	TileButtonOnOff_Click
	
	' Toggle Button
	TileButtonToggle.SetStateFontFontAwesome
	TileButtonToggle.State = False
	TileButtonToggle_Click
	
	' LevelIndicator
	TileLevel1.Value = 25
End Sub

' ================================================================
' BUTTONS
' ================================================================

Private Sub TileButtonOnOff_Click
	TileButtonOnOff.SetStateOnOff(TileButtonOnOff.State)
	TileButtonOnOff.StateText = IIf(TileButtonOnOff.State, "ON", "OFF")
	TileEventViewer1.Insert($"[TileButtonOnOff] state=${TileButtonOnOff.State}"$, TileUtils.EVENT_LEVEL_INFO)
End Sub

' Button with fontawesome looks like a toggle switch.
Private Sub TileButtonToggle_Click
	TileButtonToggle.StateText = IIf(TileButtonToggle.State, Chr(0xF205), Chr(0xF204)) ' FA toggle-on / toggle-off
	TileEventViewer1.Insert($"[TileButtonToggle] state=${TileButtonToggle.State}"$, TileUtils.EVENT_LEVEL_INFO)
End Sub

Private Sub TileButtonAlarm_Click
	TileEventViewer1.Insert($"[TileButtonAlarm] state=${TileButtonToggle.State}"$, TileUtils.EVENT_LEVEL_ALARM)
End Sub

' ================================================================
' RGB
' ================================================================

Private Sub TileRGB1_ValueChanged (m As Map)
	
End Sub

' ================================================================
' SLIDER
' ================================================================

Private Sub TileSlider1_ValueChanged (value As Int)
	TileEventViewer1.Insert($"[TileSlider1_ValueChanged] value=${value}"$, TileUtils.EVENT_LEVEL_INFO)
End Sub

' ================================================================
' EVENTVIEWER
' ================================================================

Private Sub TileEventViewer1_ItemClick (Index As Int, Value As Object)
	TileEventViewer1.Insert($"[TileEventViewer1_ItemClick] index=${Index}, value=${Value}"$, TileUtils.EVENT_LEVEL_INFO)
End Sub
