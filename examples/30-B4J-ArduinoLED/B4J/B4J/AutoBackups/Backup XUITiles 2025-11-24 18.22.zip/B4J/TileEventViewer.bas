﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=10.3
@EndOfDesignText@
#Region Class Header
' ================================================================
' File:     TileEventViewer.bas
' Brief:    Tile with a title, customlistview and trash icon (clear all event messages).
'			The customlistview contains an event list with each line being an event (Or "event message")
' Date:		2025-11-24
' Author:	Robert W.B. Linn (c) 2025 MIT
' Layout:
'			+------------------+
'			|      Label       |   
'			|+----------------+|   
'			||   Event Msg    ||   
'			||   Event Msg    ||   
'			|+----------------+|   
'			|    		[CLEAR]|
'			+------------------+
' ISA-101:	Terminology for events
'			ISA-101 describes operator interface elements (HMI displays, alarms, events, etc.) and distinguishes between:
'			Alarm - Something that requires operator action.
'			Event - A system-generated message that does Not require operator action.
'			Message / Event Message - The textual representation of an event.
' ================================================================
#End Region

' Designer Properties
#DesignerProperty: Key: TitleText, 	DisplayName: Title, FieldType: String, DefaultValue: Event Viewer
#DesignerProperty: Key: TimeStamp, 	DisplayName: Timestamp, FieldType: Boolean, DefaultValue: True, Description: Add timestamp as event message prefix. 
#DesignerProperty: Key: MaxItems, DisplayName: Max Items, FieldType: Int, DefaultValue: 50, Description: Maximum number of event messages.

' Events
#Event: ItemClick (Index As Int, Value As Object)

Sub Class_Globals
	' FX
	Private fx As JFX
	
	' Events
	Private mEventName As String	'ignore
	Private mCallBack As Object		'ignore

	' Base Views
	Public mBase As B4XView
	Public mLbl As B4XView
	Public Tag As Object

	' UI
	Private xui As XUI
	Private LabelTitle As B4XView
	Private ClvEvents As CustomListView
	Private PaneEventViewer As B4XView
	Private LabelClear As B4XView
	
	' Properties
	Private mTimeStamp As Boolean
	Private mMaxEvents As Int
End Sub

Public Sub Initialize (Callback As Object, EventName As String)
	mEventName = EventName
	mCallBack = Callback
End Sub

Public Sub DesignerCreateView (Base As Object, Lbl As Label, Props As Map)
	mBase = Base
	mLbl = Lbl
	Tag = mBase.Tag
	mBase.Tag = Me

	CallSubDelayed2(Me, "AfterLoadLayout", Props)
End Sub

Private Sub AfterLoadLayout(Props As Map)
	' First resize the base before loading the layout else customlistview not properly shown.
	Base_Resize(mBase.Width, mBase.Height)

	' Layout with label & clv
	mBase.LoadLayout("TileEventViewer")

	' Assign designer properties
	LabelTitle.Text = Props.Get("TitleText")
	mTimeStamp = Props.Get("TimeStamp")
	mMaxEvents= Props.Get("MaxItems")

	' UI settings
	' For an ISA-101–compliant HMI, the clear events icon is a non-process, non-critical UI action, 
	' so the color must follow the neutral control element rules.
	LabelClear.TextColor = TileUtils.COLOR_TEXT_SECONDARY

	' Set clv transparant
	ApplyStyle
End Sub

Private Sub Base_Resize(Width As Double, Height As Double)
	If Not(LabelTitle.IsInitialized) Or Not(ClvEvents.IsInitialized) Then
		Return
	End If

	Dim pad As Int = TileUtils.TILE_BORDER_WIDTH + 4dip

	PaneEventViewer.SetLayoutAnimated(0, pad, pad, Width - pad * 2, Height - pad * 2)
	LabelTitle.SetLayoutAnimated(0, 0, 0, PaneEventViewer.Width, TileUtils.EVENT_TITLE_HEIGHT)
End Sub

' ========== Getters / Setters ==========

' Title
' Get/Set tile title.
' Parameters:
'	text String - Tile title.
Public Sub setTitle(text As String)
	LabelTitle.Text = text
End Sub
Public Sub getTitle As String
	Return LabelTitle.Text
End Sub

Public Sub setEnabled(enabled As Boolean)
	mBase.Enabled = enabled
	If mBase.enabled Then
		mBase.Alpha = 1
	Else
		mBase.Alpha = 0.4
	End If
End Sub
Public Sub getEnabled As Boolean
	Return mBase.Enabled
End Sub

' MaxItems
' Get/Set number of max event items (default 50).
' Parameters:
'	value Int - Number of max items.
Public Sub setMaxItems(value As Int)
	mMaxEvents = value
	' Remove only if needed
	Do While ClvEvents.Size > mMaxEvents
		ClvEvents.RemoveAt(ClvEvents.Size - 1) ' safely remove last (oldest) item
	Loop
End Sub
Public Sub getMaxItems As Int
	Return mMaxEvents
End Sub

' ================================================================
' TILE STYLING
' ================================================================
#Region Tile Styling
Public Sub ApplyStyle

	LabelTitle.TextColor	= TileUtils.COLOR_TEXT_SECONDARY
	LabelTitle.TextSize 	= TileUtils.TEXT_SIZE_TITLE

	TileUtils.SetCLVBackgroundTransparent(ClvEvents)

	mBase.SetColorAndBorder(TileUtils.COLOR_BACKGROUND_TILE_DEFAULT, _
							TileUtils.TILE_BORDER_WIDTH, _ 
							TileUtils.COLOR_STATE_ON_BORDER, _ 
							TileUtils.TILE_BORDER_RADIUS)
End Sub
#End Region

' ================================================================
' ClvEvents
' ================================================================
' Insert
' Insert new event item at first position:
' Newest on top, Most relevant information visible without scrolling.
' This is aligned with industrial HMI practice.
' Parameters:
'	item String - Item to create.
'	level Int - Event level
' Returns:
'	n/a
Public Sub Insert(item As String, level As Int)
	ClvEvents.InsertAt(0, _
					ClvEventsCreateItem(item, level), _
			        item)
	If ClvEvents.Size > mMaxEvents Then
		ClvEvents.RemoveAt(ClvEvents.Size - 1)
	End If
End Sub

' Add
' Add new event item at last position and scroll to last position.
' Not recommended - use Insert.
' Parameters:
'	item String - Item to create.
'	level Int - Eventlevel
' Returns:
'	n/a
Public Sub Add(item As String, level As Int)
	ClvEvents.Add(ClvEventsCreateItem(item, level), _
			   item)
	If ClvEvents.Size > mMaxEvents Then
		ClvEvents.RemoveAt(0)
	End If
	ClvEvents.JumpToItem(ClvEvents.Size - 1)
End Sub

' Create event item.
' Parameters:
'	item String - Item to create.
'	level Int - Event level
' Returns:
'	Pane
Private Sub ClvEventsCreateItem(item As String, level As Int) As Pane

	Dim pnl As B4XView = xui.CreatePanel("")
	pnl.SetLayoutAnimated(0, TileUtils.EVENT_ITEM_PADDING, TileUtils.EVENT_ITEM_PADDING, ClvEvents.AsView.Width - (TileUtils.EVENT_ITEM_PADDING * 2), TileUtils.EVENT_ITEM_HEIGHT)

	Dim bgColor As Int = TileUtils.EVENT_COLOR_INFO_BG
	Dim txtColor As Int = TileUtils.EVENT_COLOR_INFO_TEXT
	
	Select level
		Case TileUtils.TILE_STATE_NORMAL         ' Info
			bgColor = TileUtils.EVENT_COLOR_INFO_BG
			txtColor = TileUtils.EVENT_COLOR_INFO_TEXT
	
		Case TileUtils.TILE_STATE_WARNING        ' Warning / Amber
			bgColor = TileUtils.EVENT_COLOR_WARNING_BG
			txtColor = TileUtils.EVENT_COLOR_WARNING_TEXT
	
		Case TileUtils.TILE_STATE_ALARM          ' Alarm / Red
			bgColor = TileUtils.EVENT_COLOR_ALARM_BG
			txtColor = TileUtils.EVENT_COLOR_ALARM_TEXT
	
		Case TileUtils.TILE_STATE_DISABLED       ' Disabled
			bgColor = TileUtils.EVENT_COLOR_DISABLED_BG
			txtColor = TileUtils.EVENT_COLOR_DISABLED_TEXT
	End Select
	pnl.Color = bgColor

	Dim lbl As B4XView = XUIViewsUtils.CreateLabel
	If mTimeStamp Then
		item = $"${FormatTimestamp(DateTime.Now)} - ${item}"$
	End If
	lbl.Text = item
	lbl.SetTextAlignment("CENTER", "LEFT")
	lbl.Font = xui.CreateDefaultFont(TileUtils.EVENT_TEXT_SIZE_MESSAGE)
	lbl.TextColor = txtColor
	pnl.AddView(lbl, 0, 0, pnl.Width, pnl.Height)
	Return pnl
End Sub

Private Sub ClvEvents_ItemClick (Index As Int, Value As Object)
	If SubExists(mCallBack, mEventName & "_Click") Then
		CallSub3(mCallBack, mEventName & "_Click", Index, Value)
	End If
End Sub
#End Region

' Clear all events from the list.
Public Sub Clear
	ClvEvents.Clear
End Sub

' Clear all events from the list.
Private Sub LabelClear_MouseClicked (EventData As MouseEvent)
	Clear
End Sub

' Option to format the event item timestamp
Private Sub FormatTimestamp(ts As Long) As String
	Return DateTime.Time(ts)
End Sub
