﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=10.3
@EndOfDesignText@
#Region Class Header
' ================================================================
' File: 	TileLabel.bas
' Brief:	Tile with a single label centered.
'			Style can be set to Normal, Warning, Error or Dimmed.
' Hints: 	Tile can not be resized after form loaded.
' 			DesignerProperty FieldType - One of the following values (case insensitive): String, Int, Float, Boolean or Color.
' Layout:
' +-----+
' |+---+|
' || T ||
' |+---+|
' +-----+
' ================================================================
#End Region

' Views
#DesignerProperty: Key: Text, DisplayName: Text, FieldType: String, DefaultValue: Text
#DesignerProperty: Key: TypeStyle, DisplayName: Style, FieldType: String, List: Normal|Warning|Error|Dimmed, DefaultValue: Normal

' Events
#Event: Click(EventData As MouseEvent)

Sub Class_Globals
	' Base
	Public mBase As B4XView
	Public mLbl As B4XView
	Public Tag As Object

	' Events
	Private mEventName As String 'ignore
	Private mCallBack As Object 'ignore
	
	' XUI
	Private xui As XUI 'ignore
	Private LabelText As B4XView

	' Properties (designer)
	Private mTileBackgroundColor As Int
	Private mTileBorderColor As Int
	Private mTileBorderWidth As Int
	Private mTileBorderRadius As Double
	Private mTileTextStyleBold As Boolean
	Private mTypeStyle As String
	Private mEnabled As Boolean = True

	' Properties (fixed)
End Sub

Public Sub Initialize (Callback As Object, EventName As String)
	mEventName = EventName
	mCallBack = Callback
End Sub

'Base type must be Object
Public Sub DesignerCreateView (Base As Object, Lbl As Label, Props As Map)
	mBase = Base
	' Capture the designer properties to class vars - prior assigning me to mbase.Tag
	mTileBackgroundColor = mBase.Color
	mLbl = Lbl

	' Get the mBase as a pane to get style properties	
	Dim p As Pane = mBase
'		Possible view styles
'		-fx-font-size:15.00;-fx-background-color:#008080;
'		-fx-border-color:#FF0000;
'		-fx-border-radius:3.00;-fx-background-radius:3.00;-fx-border-width:2.00;
'		-fx-font-size:15.00;-fx-background-color:#FFFFFF;
'		-fx-border-color:#0000FF;
'		-fx-border-width:4.00;
	mTileBorderWidth	= CSSUtils.GetStyleProperty(p, "-fx-border-width")
	mTileBorderRadius	= TileUtils.GetStyleBorderRadius(p)
	mTileBorderColor	= TileUtils.HexToColor(CSSUtils.GetStyleProperty(p, "-fx-border-color"))
	mTileTextStyleBold	= TileUtils.GetStyleBold(Lbl)
	mTypeStyle = Props.Get("TypeStyle")

	' Set tag 	
	Tag = mBase.Tag
	mBase.Tag = Me

	' Load the customview layout(s) via CallSubDelayed.
	CallSubDelayed2(Me, "AfterLoadLayout", Props)
End Sub

Sub AfterLoadLayout(Props As Map)	'ignore
	mBase.LoadLayout("TileLabel")
	' Assign the label properties to the LabelText
	LabelText = TileUtils.CopyLabelProps(mLbl, LabelText)
	TileUtils.SetStyleBold(LabelText, mTileTextStyleBold)

	' Set special tile types
	Select mTypeStyle
		Case "Normal"
			' These are set previous
		Case "Warning"
			LabelText.TextColor = TileUtils.COLOR_TEXT_WARNING	' Amber
		Case "Error"
			LabelText.TextColor = TileUtils.COLOR_TEXT_WARNING	' Red 600
		Case "Dimmed"
			LabelText.TextColor = xui.Color_DarkGray
	End Select

	ApplyTileBorder

	' Resize to get the sizing right
	Base_Resize(mBase.Width, mBase.Height)
End Sub

Private Sub Base_Resize (Width As Double, Height As Double)
	' Only resize if view is initialized
	If Not(LabelText.IsInitialized) Then Return

	Dim offset As Int = mTileBorderWidth
	LabelText.SetLayoutAnimated(0, offset, offset, Width - offset*2, Height - offset*2)
End Sub

' Getter/Setter

Public Sub setTileColor(value As Int)
	mBase.Color = value
	LabelText.Color = mBase.Color
End Sub
Public Sub getTileColor As Int
	Return mBase.Color
End Sub

Public Sub setTextColor(value As Int)
	LabelText.TextColor = value
End Sub
Public Sub getTextColor As Int
	Return LabelText.TextColor
End Sub

Public Sub setText(text As String)
	LabelText.Text = text
End Sub
Public Sub getText As String
	Return LabelText.Text
End Sub

Public Sub setTextSize(value As Int)
	LabelText.TextSize = value
End Sub
Public Sub getTextSize As Int
	Return LabelText.TextSize
End Sub

Public Sub setTextStyleBold(value As Boolean)
	TileUtils.SetStyleBold(LabelText, value)
End Sub
Public Sub getTextStyleBold As Boolean
	Return CSSUtils.GetStyleProperty(LabelText, "-fx-font-weight") == "bold"
End Sub

Public Sub setEnabled(enabled As Boolean)
	mBase.Enabled = enabled
	mEnabled = mBase.Enabled
	If enabled Then
		mBase.Alpha = 1
	Else
		mBase.Alpha = 0.4
	End If
End Sub

Public Sub getEnabled As Boolean
	Return mEnabled
End Sub

Public Sub SetStateColor(success As Boolean)
	If success Then
		mTileBackgroundColor = TileUtils.COLOR_TILE_STATE_ON	' green
	Else
		mTileBackgroundColor = TileUtils.COLOR_TILE_STATE_OFF	' red
	End If
	ApplyTileBorder
End Sub

Private Sub ApplyTileBorder
	mBase.SetColorAndBorder(mTileBackgroundColor, mTileBorderWidth, mTileBorderColor, mTileBorderRadius)
End Sub

Private Sub LabelText_MouseClicked (EventData As MouseEvent)
	If SubExists(mCallBack, mEventName & "_Click") Then
		CallSub2(mCallBack, mEventName & "_Click", EventData)
	End If
End Sub
