﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=10.3
@EndOfDesignText@
#Region Class Header
' ================================================================
' File:     TileButton.bas
' Brief:    Tile that behaves like a button (clickable).
'           Supports Normal, Warning, Error, Dimmed styles.
' Modes:	This TileButton is One CustomView but with Multiple Behaviors:
'			Normal Button - Set text as normal label
'				TileButton1.Text = "Start"
'			Toggle Button - Using FA toggle icons
'				TileButton1.Text = IIf(newState, Chr(0xF205), Chr(0xF204))
'			Switch - Use “ON / OFF”
'				TileButton1.Text = IIf(newState, "ON", "OFF")
'			Light Bulb Control
'				TileButton1.Text = IIf(newState, Chr(0xF0EB), Chr(0xF111))
'			Lock/Unlock
'				TileButton1.Text = IIf(locked, Chr(0xF023), Chr(0xF09C)) 
'			Open/Close
'				TileButton1.Text = IIf(isOpen, Chr(0xF2C2), Chr(0xF2C1))
'
' Example Callback: UI follows actual device state
' Button with text change
'Private Sub TileButton1_Click
'	Dim state As Boolean = Not(DevYellowLed.Get)
'	DevYellowLed.Set(state)
'	TileButton1.Text = IIf(state, "ON", "OFF")
'	TileButton1.SetStateColor(state)
'End Sub

' Button with fontawesome looks like a switch
'Private Sub TileButton2_Click
'	Dim newstate As Boolean = Not(DevYellowLed.Get)
'	DevYellowLed.Set(newstate)
'	TileButton2.Text = IIf(newstate, Chr(0xF205), Chr(0xF204)) ' FA toggle-on / toggle-off
'End Sub
'
' ================================================================
#End Region

' Designer Properties
#DesignerProperty: Key: TitleText, DisplayName: Title, FieldType: String, DefaultValue: Title
#DesignerProperty: Key: StateText, DisplayName: State, FieldType: String, DefaultValue: Button
#DesignerProperty: Key: TypeStyle, DisplayName: Button Style, FieldType: String, List: Normal|Warning|Error|Dimmed, DefaultValue: Normal

' Events
#Event: Click

Sub Class_Globals
	' Base
	Public mBase As B4XView
	Public mLbl As B4XView
	Public Tag As Object

	' Events
	Private mEventName As String
	Private mCallBack As Object

	' UI
	Private xui As XUI
	Private LabelTitle As B4XView
	Private LabelState As B4XView

	' Designer properties
	Private mTileBackgroundColor As Int
	Private mTileBorderColor As Int
	Private mTileBorderWidth As Int
	Private mTileBorderRadius As Double
	Private mTileTextStyleBold As Boolean
	Private mTypeStyle As String

	' Fixed properties
	Private mEnabled As Boolean = True
	Private mIsPressed As Boolean = False			'ignore
	Private mState As Boolean = False
End Sub

Public Sub Initialize (Callback As Object, EventName As String)
	mEventName = EventName
	mCallBack = Callback
End Sub

Public Sub DesignerCreateView (Base As Object, Lbl As Label, Props As Map)
	mBase = Base
	' Capture the designer properties to class vars - prior assigning me to mbase.Tag
	mTileBackgroundColor = mBase.Color
	mLbl = Lbl

	Dim p As Pane = mBase
	mTileBorderWidth = CSSUtils.GetStyleProperty(p, "-fx-border-width")
	mTileBorderRadius = TileUtils.GetStyleBorderRadius(p)
	mTileBorderColor = TileUtils.HexToColor(CSSUtils.GetStyleProperty(p, "-fx-border-color"))
	mTileTextStyleBold = TileUtils.GetStyleBold(Lbl)
	mTypeStyle = Props.Get("TypeStyle")

	Tag = mBase.Tag
	mBase.Tag = Me

	CallSubDelayed2(Me, "AfterLoadLayout", Props)
End Sub

Private Sub AfterLoadLayout(Props As Map)	'ignore
	mBase.LoadLayout("TileButton")
	mBase.Color = mTileBackgroundColor

	' Assign the label properties to the labels
	LabelTitle = TileUtils.CopyLabelProps(mLbl, LabelTitle)
	LabelTitle.Text = Props.Get("TitleText")
	LabelState = TileUtils.CopyLabelProps(mLbl, LabelState)
	' Label state text is set from the mLbl text
	TileUtils.SetStyleBold(LabelState, mTileTextStyleBold)

	' Style types
	Select mTypeStyle
		Case "Normal"
		Case "Warning"
			LabelState.TextColor = TileUtils.COLOR_TEXT_WARNING
		Case "Error"
			LabelState.TextColor = TileUtils.COLOR_TEXT_ERROR
		Case "Dimmed"
			LabelState.TextColor = xui.Color_DarkGray
	End Select

	ApplyTileBorder

	Base_Resize(mBase.Width, mBase.Height)
End Sub

Private Sub Base_Resize(Width As Double, Height As Double)
	If Not(LabelTitle.IsInitialized) Or Not(LabelState.IsInitialized) Then Return

	Dim pad As Int = mTileBorderWidth + 4dip
	
	LabelTitle.SetLayoutAnimated(0, pad, pad, Width - pad*2, Height * 0.25)
	LabelState.SetLayoutAnimated(0, pad, Height*0.25, Width - pad*2, Height*0.50)
End Sub

' ================================================================
' Getter / Setter
' ================================================================

Public Sub setStateText(value As String)
	LabelState.Text = value
End Sub
Public Sub getStateText As String
	Return LabelState.Text
End Sub

Public Sub setStateTextSize(value As Int)
	LabelState.TextSize = value
End Sub
Public Sub getStateTextSize As Int
	Return LabelState.TextSize
End Sub

Public Sub setStateTextColor(value As Int)
	LabelState.TextColor = value
End Sub
Public Sub getStateTextColor As Int
	Return LabelState.TextColor
End Sub

Public Sub setState(state As Boolean)
	mState = state
End Sub
Public Sub getState As Boolean
	Return mState
End Sub

Public Sub SetStateColor(success As Boolean)
	If success Then
		mTileBackgroundColor = TileUtils.COLOR_TILE_STATE_ON
	Else
		mTileBackgroundColor = TileUtils.COLOR_TILE_STATE_OFF
	End If
	ApplyTileBorder
End Sub

Public Sub SetBackgroundColor(clr As Int)
	mTileBackgroundColor = clr
	ApplyTileBorder
End Sub

Public Sub setTitleText(value As String)
	LabelTitle.Text = value
End Sub
Public Sub getTitleText As String
	Return LabelTitle.Text
End Sub

Public Sub setTitleTextSize(value As Int)
	LabelTitle.TextSize = value
End Sub
Public Sub getTitleTextSize As Int
	Return LabelTitle.TextSize
End Sub

Public Sub setTitleTextColor(value As Int)
	LabelTitle.TextColor = value
End Sub
Public Sub getTitleTextColor As Int
	Return LabelTitle.TextColor
End Sub

Public Sub setEnabled(enabled As Boolean)
	mBase.Enabled = enabled
	mEnabled = mBase.Enabled
	If enabled Then
		mBase.Alpha = 1
	Else
		mBase.Alpha = 0.4
	End If
End Sub

Public Sub getEnabled As Boolean
	Return mEnabled
End Sub

Public Sub SetInfo(text As String)
	setStateText(text)
	SetBackgroundColor(TileUtils.COLOR_ICON_WARNING)
End Sub

Public Sub SetWarning(text As String)
	setStateText(text)
	SetBackgroundColor(TileUtils.COLOR_ICON_WARNING)
End Sub

Public Sub SetError(text As String)
	setStateText(text)
	SetBackgroundColor(TileUtils.COLOR_ICON_ERROR)
End Sub


' ================================================================
' Internal Graphics
' ================================================================

Private Sub ApplyTileBorder
	mBase.SetColorAndBorder(mTileBackgroundColor, mTileBorderWidth, mTileBorderColor, mTileBorderRadius)
End Sub

' ================================================================
' Mouse Events (Button Behavior)
' ================================================================

Private Sub LabelState_MouseEntered (EventData As MouseEvent)
    If mEnabled Then mBase.Alpha = 0.85
End Sub

Private Sub LabelState_MouseClicked(EventData As MouseEvent)
	mState = Not(mState)
	If SubExists(mCallBack, mEventName & "_Click") Then
		CallSub(mCallBack, mEventName & "_Click")
	End If
End Sub

Private Sub LabelState_MousePressed (EventData As MouseEvent)
	mIsPressed = True
	mBase.Alpha = 0.7   ' visual feedback
End Sub

Private Sub LabelState_MouseReleased (EventData As MouseEvent)
	mIsPressed = False
	mBase.Alpha = 1.0
End Sub
