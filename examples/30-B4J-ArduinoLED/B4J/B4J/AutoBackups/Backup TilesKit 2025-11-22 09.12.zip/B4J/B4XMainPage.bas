﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=9.85
@EndOfDesignText@

#Region Shared Files
#CustomBuildAction: folders ready, %WINDIR%\System32\Robocopy.exe,"..\..\Shared Files" "..\Files"
'Ctrl + click to sync files: ide://run?file=%WINDIR%\System32\Robocopy.exe&args=..\..\Shared+Files&args=..\Files&FilesSync=True
#End Region

'Ctrl + click to export as zip: ide://run?File=%B4X%\Zipper.jar&Args=Project.zip
'You can see the list of page related events in the B4XPagesManager object. The event name is B4XPage.

Sub Class_Globals
	Private VERSION As String = "TilesKit v20251122"
	
	' UI
	Private xui As XUI
	Private Root As B4XView
	Private TileButton1 As TileButton
	Private LabelAbout As B4XView
End Sub

Public Sub Initialize
'	B4XPages.GetManager.LogEvents = True
End Sub

'This event will be called once, before the page becomes visible.
Private Sub B4XPage_Created (Root1 As B4XView)
	Root = Root1
	Root.LoadLayout("MainPage")
	
	' UI  additional settings
	B4XPages.GetNativeParent(Me).Title = VERSION
	LabelAbout.Text = $"${VERSION} (c) 2025 Robert W.B. Linn - MIT"$
End Sub

Private Sub TileButton1_Click
	xui.MsgboxAsync("Hello world!", "B4X")
End Sub