﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=10.3
@EndOfDesignText@
#Region Class Header
' ================================================================
' File: 	TileLevel.bas
' Brief:	Tile with a level bar 0-100%.
'			Style can be set to Normal, Warning, Alarm or Dimmed.
' Layout:
'+------------------+
'|       Title      |  	<< 25 % (top-aligned Or centered)
'|       Level      |	<< 50% (midlle centered)
'|        bar       |  
'| 	   Value Unit   |	<< 25% (center Or bottom)
'+------------------+
' ================================================================
#End Region

' Designer properties
#DesignerProperty: Key: TitleText, DisplayName: Title, FieldType: String, DefaultValue: Level
#DesignerProperty: Key: Value, DisplayName: Value, FieldType: Float, DefaultValue: 0
#DesignerProperty: Key: UnitText,  DisplayName: Unit,  FieldType: String, DefaultValue: 
#DesignerProperty: Key: TypeStyle, DisplayName: Tile Style, FieldType: String, List: Normal|Warning|Alarm|Dimmed, DefaultValue: Normal

' Events
#Event: Click(EventData As MouseEvent)

Sub Class_Globals
	Private mEventName As String
	Private mCallBack As Object

	Public mBase As B4XView
	Public mLbl As B4XView

	Private xui As XUI
	Public Tag As Object

	' Views inside TileSensor.bjl
	Private LabelTitle As B4XView
	Private PaneBar As B4XView
	Private PaneFill As B4XView
	Private LabelValue As B4XView

	' Designer values
	Private mValue As Float
	Private mUnitText As String
End Sub


Public Sub Initialize(Callback As Object, EventName As String)
	mEventName = EventName
	mCallBack = Callback
End Sub


Public Sub DesignerCreateView(Base As Object, Lbl As Label, Props As Map)
	mBase = Base
	mLbl = Lbl
	Tag = mBase.Tag
	mBase.Tag = Me
	CallSubDelayed2(Me, "AfterLoadLayout", Props)
End Sub

Private Sub AfterLoadLayout(Props As Map)	'ignore
	mBase.LoadLayout("TileLevel")

	' Store designer properties
	LabelTitle.Text = Props.Get("TitleText")
	LabelValue.Text = Props.Get("Value")
	mValue			= Props.Get("Value")
	mUnitText		= Props.Get("UnitText")
	setValue(mValue)

	' Ensure the font is set to FA
	ApplyStyle(Props.Get("TypeStyle"))
	Base_Resize(mBase.Width, mBase.Height)
End Sub

Private Sub Base_Resize(Width As Double, Height As Double)
	If Not(LabelValue.IsInitialized) Then Return

	Dim pad As Int = TileUtils.TILE_BORDER_WIDTH + 4dip

	LabelTitle.SetLayoutAnimated(0, pad, pad, Width - pad*2, Height * 0.25)

	UpdateLevel
				
	LabelValue.SetLayoutAnimated(0, pad, Height*0.75, Width - pad*2, Height*0.25)
End Sub

' Update level bar with level 0 check.
Private Sub UpdateLevel
	Dim pad As Int = TileUtils.TILE_BORDER_WIDTH + 4dip
	Dim l As Int = mBase.width / 4
	Dim t As Int = LabelTitle.Top + LabelTitle.Height + pad
	Dim w As Int = mBase.width / 2
	Dim h As Int = (mBase.height * 0.50) - (pad * 2)
	
	Dim pct As Float = 0
	If mValue > 0 Then
		pct = mValue / 100
	End If
	Dim fillheight As Float = h * pct

	' Bar
	PaneBar.SetLayoutAnimated(0, l, t, w, h)

	' Level
	pad = TileUtils.TILE_BORDER_WIDTH
	l = l + pad
	t = t + h - fillheight
	w = w - pad * 2
	h = IIf(fillheight > 0, fillheight, 0)
	PaneFill.SetLayoutAnimated(0, l, t, w, h)
End Sub

' ===================================================================
' Public API
' ===================================================================
' Title
Public Sub setTitle(title As String)
	LabelTitle.Text = title
End Sub
Public Sub getTitle As String
	Return LabelTitle.Text
End Sub

' Value
Public Sub setValue(value As Float)
	mValue = value
	UpdateLevel
	Dim v As String = mValue
	If v.Contains(".") Then
		LabelValue.Text = $"${mValue}${IIf(mUnitText.Length > 0, $" ${mUnitText}"$, "")}"$
	Else
		LabelValue.Text = $"${NumberFormat(mValue,0,0)}${IIf(mUnitText.Length > 0, $" ${mUnitText}"$, "")}"$
	End If
End Sub
Public Sub getValue As Float
	Return mValue
End Sub

Public Sub setUnit(unit As String)
	mUnitText = unit
	LabelValue.Text = $"${mValue}${IIf(mUnitText.Length > 0, $" ${mUnitText}"$, "")}"$
End Sub
Public Sub getUnit As String
	Return LabelValue.Text
End Sub

Public Sub setEnabled(enabled As Boolean)
	mBase.Enabled = enabled
	If mBase.enabled Then
		mBase.Alpha = 1
	Else
		mBase.Alpha = 0.4
	End If
End Sub

Public Sub getEnabled As Boolean
	Return mBase.Enabled
End Sub

Private Sub LabelIcon_MouseClicked(EventData As MouseEvent)
	If SubExists(mCallBack, mEventName & "_Click") Then
		CallSub2(mCallBack, mEventName & "_Click", EventData)
	End If
End Sub

' ================================================================
' TILE STYLING
' ================================================================
#Region Tile Styling
Public Sub ApplyStyle(tilestate As String)
	LabelTitle.TextColor = TileUtils.COLOR_TEXT_SECONDARY
	LabelTitle.TextSize = TileUtils.TEXT_SIZE_TITLE

	LabelValue.TextSize = TileUtils.TEXT_SIZE_LABEL
	LabelValue.TextColor = TileUtils.COLOR_TEXT_PRIMARY

	Dim state As Int = TileUtils.StateStyleToState(tilestate)

	Select state
		Case TileUtils.TILE_STATE_NORMAL
			PaneFill.Color = TileUtils.TILE_COLOR_NORMAL_BACKGROUND
		Case TileUtils.TILE_STATE_WARNING
			PaneFill.Color = TileUtils.TILE_COLOR_WARNING_BACKGROUND
		Case TileUtils.TILE_STATE_ALARM
			PaneFill.Color = TileUtils.TILE_COLOR_ALARM_BACKGROUND
		Case TileUtils.TILE_STATE_DISABLED
			PaneFill.Color = TileUtils.TILE_COLOR_DISABLED_BACKGROUND
	End Select

	' --- ISA-101 Tile Border ---
	mBase.SetColorAndBorder( _
        mBase.Color, _
        TileUtils.TILE_BORDER_WIDTH, _
        TileUtils.COLOR_STATE_ON_BORDER, _
        TileUtils.TILE_BORDER_RADIUS)

	' --- Bar Border (thin fixed) ---
	PaneBar.SetColorAndBorder( _
        mBase.Color, _ 	' TileUtils.COLOR_BACKGROUND_TILE_DEFAULT, _
        1dip, _
        TileUtils.COLOR_TEXT_SECONDARY, _
        0dip)
End Sub

#End Region#End Region
