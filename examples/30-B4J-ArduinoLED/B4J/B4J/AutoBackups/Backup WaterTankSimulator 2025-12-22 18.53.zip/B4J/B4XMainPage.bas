﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=9.85
@EndOfDesignText@
' ================================================================
' File:			WaterTankSimulator
' Brief:		A simple interactive water tank PID simulator demonstrating ISA-101–style HMI design using HMITiles.
' Date:			2025-12-22
' Author:		Robert W.B. Linn (c) 2025 MIT
' Description:	WaterTankSimulator is a lightweight B4J demo application that simulates a controlled water tank process with input flow, tank level, and output flow.
'				It showcases the practical use of HMITiles (SP/PV tiles, mini trends, And readouts) following ISA-101 high-performance HMI principles.
'				The simulator includes dynamic process behavior, trend visualization, And setpoint control, making it ideal For demonstrations, experimentation, And HMI design validation.
' 				Important:
'				Input trend shows disturbance (PV)
' 				Tank trend shows controlled process value (PV)
'				Tiles mapping:
'				| Component        | Tile Type        | Function                                      |
'				| ---------------- | ---------------- | --------------------------------------------- |
'				| Input Flow       | HMITileSPPV      | Setpoint / PV input, trend visualization      |
'				| Tank Level       | HMITileSPPV      | Setpoint / PV tank level, trend visualization |
'				| Output Flow      | HMITileReadOut   | Just display output flow value                |
'				| Trend Mini Input | HMITileTrendMini | Shows input flow history                      |
'				| Trend Mini Tank  | HMITileTrendMini | Shows tank level history                      |
' ================================================================

#Region Shared Files
#CustomBuildAction: folders ready, %WINDIR%\System32\Robocopy.exe,"..\..\Shared Files" "..\Files"
#End Region

Sub Class_Globals
	Private VERSION As String	= "Water Tank Simulator"
	Private ABOUT As String 	= $"${VERSION} (c) 2025 Robert W.B. Linn - MIT"$
	
	' UI
	Private xui As XUI
	Private Root As B4XView
	Private LabelAbout As B4XView
	
	' UI HMITiles
	Private TileButtonOnOff As HMITileButton
	Private TileSPPVInput As HMITileSPPV
	Private TileTrendInput As HMITileTrendMini
	Private TileSPPVTankLevel As HMITileSPPV
	Private TileTrendTankLevel As HMITileTrendMini
	Private TileReadoutOutput As HMITileReadout
	Private TileEvents As HMITileEventViewer
	Private TileTrendOutput As HMITileTrendMini

	' Simulator
	Private InputFlowSP As Float = 20
	Private InputFlowPV As Float
	Private TankLevelSP As Float = 50
	Private TankLevelPV As Float = TankLevelSP
	Private OutputFlow As Float

	'--- SIMPLE PID ---
	Private Kp As Float = 0.3
	Private Ki As Float = 0.6
	Private Kd As Float = 0.05
	Private Integral As Float
	Private LastError As Float
	
	' History
	Private InputHistory As List
	Private TankHistory As List
	Private OutputHistory As List

	' Data generator timer
	Private TimerSimulator As Timer
	Private TIMERSIMULATOR_INTERVAL As Long = 2000		' Every 2 seconds data change
	Private dt As Float = 0.1 							' Seconds per tick
End Sub

Public Sub Initialize
	B4XPages.GetManager.LogEvents = True
End Sub

'This event will be called once, before the page becomes visible.
Private Sub B4XPage_Created (Root1 As B4XView)
	Root = Root1
	Root.LoadLayout("MainPage")

	' UI  additional settings
	Root.Color = HMITileUtils.COLOR_BACKGROUND_SCREEN
	B4XPages.SetTitle(Me, VERSION)
	B4XPages.GetNativeParent(Me).Resizable = False
	LabelAbout.Text = ABOUT

	' Ensure to set sleep prior calling customviews
	Sleep(1)

	' Input
	TileSPPVInput.Title = "Input"
	TileSPPVInput.PV = 0
	TileSPPVInput.SP = InputFlowSP
	TileTrendInput.Title = "Input"
	
	' Tank Level
	TileSPPVTankLevel.Title = "Tank Level"
	TileSPPVTankLevel.PV = 0
	TileSPPVTankLevel.SP = TankLevelSP
	TileTrendTankLevel.Title = "Tank Level"
	
	' Output
	TileReadoutOutput.Title = "Output"
	TileReadoutOutput.Value = 0
	TileReadoutOutput.Unit = ""
	
	' Eventviewer
	TileEvents.CompactMode = False
	TileEvents.Insert(VERSION, HMITileUtils.EVENT_LEVEL_INFO)

	' OnOff Button
	TileButtonOnOff.State = False
	TileButtonOnOff_Click
	
	' Simulator
	InputHistory.Initialize
	TankHistory.Initialize
	OutputHistory.Initialize
	
	TimerSimulator.Initialize("TimerSimulator", TIMERSIMULATOR_INTERVAL)
	TimerSimulator.Enabled = True
	
End Sub

' Handle simulator tick events
Private Sub TimerSimulator_Tick
	SimulatorStep
End Sub

' SIMULATOR
Private Sub SimulatorStep
	' --- FLOW LOOP (FRC)
	InputFlowPV = InputFlowPV + (InputFlowSP - InputFlowPV) * 0.3
	InputFlowPV = InputFlowPV + (Rnd(-10,10) / 20)

	' --- LEVEL CONTROLLER (LRC)
	Dim ValveCmd As Float = PID_Control(TankLevelSP, TankLevelPV)

	' --- OUTPUT VALVE PHYSICS
	Dim ValveGain As Float = 1.2
	OutputFlow = ValveCmd * ValveGain * (TankLevelPV / 100)
	
	' --- TANK DYNAMICS
	TankLevelPV = TankLevelPV + (InputFlowPV - OutputFlow) * dt

	' Clamp
	If TankLevelPV < 0 Then TankLevelPV = 0
	If TankLevelPV > 100 Then TankLevelPV = 100

	' --- Update tiles
	InputFlowSP = TileSPPVInput.SP
	TileSPPVInput.PV = Round(InputFlowPV)
	
	' TileSPPVInput.UpdateSPPV(InputFlowSP, InputFlowPV)
	TankLevelSP = TileSPPVTankLevel.SP
	TileSPPVTankLevel.PV = NumberFormat(TankLevelPV,0,0)
	' TileSPPVTankLevel.UpdateSPPV(TankLevelSP, TankLevelPV)
	TileReadoutOutput.Value = NumberFormat(OutputFlow, 0, 1)

	' --- Update history
	InputHistory.Add(InputFlowPV)
	If InputHistory.Size > 50 Then InputHistory.RemoveAt(0)
	TileTrendInput.UpdateChart(InputHistory)
	
	TankHistory.Add(TankLevelPV)
	If TankHistory.Size > 50 Then TankHistory.RemoveAt(0)
	TileTrendTankLevel.UpdateChart(TankHistory)

	OutputHistory.Add(OutputFlow)
	If OutputHistory.Size > 50 Then OutputHistory.RemoveAt(0)
	TileTrendOutput.UpdateChart(InputHistory)
	
	Log($"[Simulator.InputFlow] PV=${InputFlowPV}, SP=${InputFlowSP}, Output=${NumberFormat(OutputFlow, 0, 1)}"$)
End Sub

Private Sub PID_Control(SetPoint As Float, PV As Float) As Float
	' Reverse acting controller (LEVEL)
	Dim error As Float = PV - SetPoint

	Integral = Integral + error * dt
	If Integral > 100 Then Integral = 100
	If Integral < 0 Then Integral = 0

	Dim out As Float = Kp * error + Ki * Integral

	' Clamp valve command
	If out < 0 Then out = 0
	If out > 100 Then out = 100

	Return out
End Sub

' ================================================================
' BUTTONS
' ================================================================
Private Sub TileButtonOnOff_Click
	TileButtonOnOff.SetState(TileButtonOnOff.State)
	TileButtonOnOff.StateText = IIf(TileButtonOnOff.State, "ON", "OFF")
	TileEvents.Insert($"[TileButtonOnOff] state=${TileButtonOnOff.State}"$, HMITileUtils.EVENT_LEVEL_INFO)
End Sub

' ================================================================
' EVENTVIEWER
' ================================================================
Private Sub TileEvents_ItemClick (Index As Int, Value As Object)
	TileEvents.Insert($"[TileEvents_ItemClick] index=${Index}, value=${Value}"$, HMITileUtils.EVENT_LEVEL_INFO)
End Sub

Private Sub TileSPPVInput_Click
	
End Sub

Private Sub TileSPPVLevel_Click
	
End Sub


Private Sub SimulatorStepX
	' --- Random disturbance on input flow 20-30 range
	InputFlowPV = 20 + Rnd(0, 100) / 10
	
	' --- PID controller to maintain TankLevelSP
	InputFlowSP = PID_Control(TankLevelSP, TankLevelPV)
	
	' --- Tank level calculation
	OutputFlow = TankLevelPV * 0.1  ' example outflow proportional to level

	TankLevelPV = TankLevelPV + (InputFlowSP - OutputFlow) * dt
	' Clamp tanklevel
	If TankLevelPV < 0 Then TankLevelPV = 0
	If TankLevelPV > 100 Then TankLevelPV = 100
	
	' --- Update history
	InputHistory.Add(InputFlowPV)
	If InputHistory.Size > 50 Then InputHistory.RemoveAt(0)
	TileTrendInput.UpdateChart(InputHistory)
	
	TankHistory.Add(TankLevelPV)
	If TankHistory.Size > 50 Then TankHistory.RemoveAt(0)
	TileTrendTankLevel.UpdateChart(TankHistory)
	
	' --- Update tiles
	TileSPPVInput.SP = Round(InputFlowSP)
	TileSPPVInput.PV = Round(InputFlowPV)
	
	' TileSPPVInput.UpdateSPPV(InputFlowSP, InputFlowPV)
	TileSPPVTankLevel.SP = TankLevelSP
	TileSPPVTankLevel.PV = NumberFormat(TankLevelPV,0,0)
	' TileSPPVTankLevel.UpdateSPPV(TankLevelSP, TankLevelPV)
	TileReadoutOutput.Value = NumberFormat(OutputFlow, 0, 1)

	Log($"[Simulator.InputFlow] PV=${InputFlowPV}, SP=${InputFlowSP}, Output=${NumberFormat(OutputFlow, 0, 1)}"$)

End Sub
