﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=10.3
@EndOfDesignText@
#Region Class Header
' ================================================================
' File:    TileImage.bas
' Brief:   ISA-101 compliant tile with Title (25%) + Image (75%).
'          Image must be located in File.DirApp.
' Layout:
' +------------------+
' |     Title        |  << 25%
' |------------------|
' |                  |
' |     Image        |  << 75%
' |                  |
' +------------------+
' ================================================================
#End Region

' Designer properties
#DesignerProperty: Key: TitleText, DisplayName: Title, FieldType: String, DefaultValue: Image
#DesignerProperty: Key: ImageName, DisplayName: Image Name, FieldType: String, DefaultValue: , Description: Name of the image located in the app folder.
#DesignerProperty: Key: TypeStyle, DisplayName: Tile Style, FieldType: String, List: Normal|Warning|Alarm|Dimmed, DefaultValue: Normal

Sub Class_Globals
	Private mEventName As String
	Private mCallBack As Object

	Public mBase As B4XView
	Public mLbl As B4XView

	Private xui As XUI
	Public Tag As Object

	' Views from TileImage.bjl
	Private LabelTitle As B4XView
	Private B4XImageViewTile As B4XImageView

	' Designer value
	Private mImageName As String
End Sub

Public Sub Initialize(Callback As Object, EventName As String)
	mEventName = EventName
	mCallBack = Callback
End Sub

Public Sub DesignerCreateView(Base As Object, Lbl As Label, Props As Map)
	mBase = Base
	mLbl = Lbl
	Tag = mBase.Tag
	mBase.Tag = Me
	CallSubDelayed2(Me, "AfterLoadLayout", Props)
End Sub

Private Sub AfterLoadLayout(Props As Map)
	mBase.LoadLayout("TileImage")

	LabelTitle.Text = Props.Get("TitleText")
	mImageName = Props.Get("ImageName")

	ApplyStyle(Props.Get("TypeStyle"))
	Base_Resize(mBase.Width, mBase.Height)
End Sub

Private Sub Base_Resize(Width As Double, Height As Double)
	If Not(LabelTitle.IsInitialized) Then Return

	Dim pad As Int = TileUtils.TILE_BORDER_WIDTH + 4dip
	Dim titleHeight As Float = Height * 0.25
	Dim imageHeight As Float = Height * 0.75 - pad * 4

	' Title area
	LabelTitle.SetLayoutAnimated(0, pad, pad, Width - pad*2, titleHeight)

	' Image area
	B4XImageViewTile.mBase.SetLayoutAnimated(0, _
        pad, _
        LabelTitle.Top + LabelTitle.Height + pad, _
        Width - pad*2, _
        imageHeight)

	' Load image if available
	If mImageName <> "" Then
		B4XImageViewTile.Bitmap = xui.LoadBitmapResize(File.DirApp, mImageName, _
            B4XImageViewTile.mBase.Width, _
            B4XImageViewTile.mBase.Height, _
            True)   ' keep aspect ratio
	End If
End Sub

' ===================================================================
' Public API
' ===================================================================

Public Sub SetTitle(title As String)
	LabelTitle.Text = title
End Sub

Public Sub SetImage(image As String)
	If image = "" Then Return
	mImageName = image
	Try
		B4XImageViewTile.Bitmap = xui.LoadBitmapResize(File.DirApp, image, _
            B4XImageViewTile.mBase.Width, _
            B4XImageViewTile.mBase.Height, _
            True)
	Catch
		Log($"[TileImage.SetImage][E] Unable to load image '${image}': ${LastException}"$)
	End Try
End Sub

Public Sub setEnabled(enabled As Boolean)
	mBase.Enabled = enabled
	mBase.Alpha = IIf(enabled, 1, 0.4)
End Sub

Public Sub getEnabled As Boolean
	Return mBase.Enabled
End Sub

' ================================================================
' TILE STYLING
' ================================================================
#Region Tile Styling
Public Sub ApplyStyle(tilestate As String)
	LabelTitle.TextColor = TileUtils.COLOR_TEXT_SECONDARY
	LabelTitle.TextSize  = TileUtils.TEXT_SIZE_TITLE

	Dim state As Int = TileUtils.StateStyleToState(tilestate)
	Select state
		Case TileUtils.TILE_STATE_NORMAL
			mBase.Color = TileUtils.TILE_COLOR_NORMAL_BACKGROUND

		Case TileUtils.TILE_STATE_WARNING
			mBase.Color = TileUtils.TILE_COLOR_WARNING_BACKGROUND

		Case TileUtils.TILE_STATE_ALARM
			mBase.Color = TileUtils.TILE_COLOR_ALARM_BACKGROUND

		Case TileUtils.TILE_STATE_DISABLED
			mBase.Color = TileUtils.TILE_COLOR_DISABLED_BACKGROUND
	End Select

	' Make image view background match tile
	B4XImageViewTile.mBackgroundColor = mBase.Color

	mBase.SetColorAndBorder( _
        TileUtils.COLOR_BACKGROUND_TILE_DEFAULT, _
        TileUtils.TILE_BORDER_WIDTH, _
        TileUtils.COLOR_STATE_ON_BORDER, _
        TileUtils.TILE_BORDER_RADIUS)
End Sub
#End Region
