﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=10.3
@EndOfDesignText@
#Region Class Header
' ================================================================
' File: 	TileSensor.bas
' Brief:	Tile with at the 
'			- top an icon/label centered
'			- bottom a label with value
'			Style can be set to Normal, Warning, Alarm or Dimmed.
' Hints: 	Tile can not be resized after form loaded.
' 			DesignerProperty FieldType - One of the following values (case insensitive): String, Int, Float, Boolean or Color.
' Layout:
'+------------------+
'|       Label      |  (top-aligned Or centered)
'|       Icon       |  (midlle centered)
'| Sensor Value Unit|  (center Or bottom)
'+------------------+
' ================================================================
#End Region

' Designer properties
#DesignerProperty: Key: TitleText, DisplayName: Title, FieldType: String, DefaultValue: Sensor
#DesignerProperty: Key: ValueText, DisplayName: Value, FieldType: String, DefaultValue: --
#DesignerProperty: Key: UnitText,  DisplayName: Unit,  FieldType: String, DefaultValue: 
#DesignerProperty: Key: Icon,      DisplayName: Icon (FontAwesome), FieldType: String, DefaultValue: , Description: Set "F043" or "f043" or real character without 0x.
#DesignerProperty: Key: TypeStyle, DisplayName: Tile Style, FieldType: String, List: Normal|Warning|Alarm|Dimmed, DefaultValue: Normal

' Events
#Event: Click(EventData As MouseEvent)

Sub Class_Globals
	Private mEventName As String
	Private mCallBack As Object

	Public mBase As B4XView
	Public mLbl As B4XView

	Private xui As XUI
	Public Tag As Object

	' Views inside TileSensor.bjl
	Private LabelTitle As B4XView
	Private LabelIcon As B4XView
	Private LabelValue As B4XView

	' Designer values
	' Private mIconScale As Float
	Private mValueText As String
	Private mUnitText As String
End Sub


Public Sub Initialize(Callback As Object, EventName As String)
	mEventName = EventName
	mCallBack = Callback
End Sub


Public Sub DesignerCreateView(Base As Object, Lbl As Label, Props As Map)
	mBase = Base
	mLbl = Lbl
	Tag = mBase.Tag
	mBase.Tag = Me
	CallSubDelayed2(Me, "AfterLoadLayout", Props)
End Sub

Private Sub AfterLoadLayout(Props As Map)	'ignore
	mBase.LoadLayout("TileSensor")

	' Store designer properties
	LabelTitle.Text = Props.Get("TitleText")
	LabelIcon.Text  = Props.Get("Icon")
	LabelValue.Text = Props.Get("ValueText")
	mValueText		= Props.Get("ValueText")
	mUnitText		= Props.Get("UnitText")
	' Ensure the font is set to FA
	SetIcon(LabelIcon.Text)
	ApplyStyle(Props.Get("TypeStyle"))
	Base_Resize(mBase.Width, mBase.Height)
End Sub

Private Sub Base_Resize(Width As Double, Height As Double)
	If Not(LabelValue.IsInitialized) Then Return

	Dim pad As Int = TileUtils.TILE_BORDER_WIDTH + 4dip

	LabelTitle.SetLayoutAnimated(0, pad, pad, Width - pad*2, Height * 0.25)
	LabelIcon.SetLayoutAnimated(0, pad, Height*0.25, Width - pad*2, Height*0.30)
	LabelValue.SetLayoutAnimated(0, pad, Height*0.55, Width - pad*2, Height*0.40)
End Sub


' ===================================================================
' Public API
' ===================================================================
' Title
Public Sub SetTitle(title As String)
	LabelTitle.Text = title
End Sub

' Icon
Public Sub SetIcon(iconHex As String)
	If iconHex == "" Then Return

	' Log($"[SetIcon] iconHex=${iconHex}, ${Bit.ParseInt(iconHex, 16)}"$)

    ' expects "F043" or "f043" or real character
    Try
        If iconHex.Length > 0 And iconHex.Length <= 6 And iconHex.ToLowerCase.StartsWith("f") Then
            LabelIcon.Text = Chr(Bit.ParseInt(iconHex, 16))
        Else
            LabelIcon.Text = iconHex
        End If
    Catch
        LabelIcon.Text = iconHex
    End Try
End Sub

Public Sub SetIconColor(clr As Int)
    LabelIcon.TextColor = clr
End Sub

Public Sub SetIconSize(size As Int)
    LabelIcon.TextSize = size
End Sub

Public Sub SetIconScale(scale As Float)
	LabelIcon.TextSize = LabelTitle.TextSize * scale
End Sub

' Value
Public Sub SetValue(value As String)
	LabelValue.Text = value & mUnitText
End Sub

Public Sub SetUnit(unit As String)
	mUnitText = unit
	LabelValue.Text =  mValueText & unit
End Sub

Public Sub SetStateColor(success As Boolean)
	TileUtils.ApplyStyleStateOnOff(mBase, LabelValue, success)
End Sub

Public Sub setEnabled(enabled As Boolean)
	mBase.Enabled = enabled
	If mBase.enabled Then
		mBase.Alpha = 1
	Else
		mBase.Alpha = 0.4
	End If
End Sub

Public Sub getEnabled As Boolean
	Return mBase.Enabled
End Sub

Private Sub LabelIcon_MouseClicked(EventData As MouseEvent)
	If SubExists(mCallBack, mEventName & "_Click") Then
		CallSub2(mCallBack, mEventName & "_Click", EventData)
	End If
End Sub

' ================================================================
' TILE STYLING
' ================================================================
#Region Tile Styling
Public Sub ApplyStyle(tilestate As String)
	LabelTitle.TextColor 	= TileUtils.COLOR_TEXT_SECONDARY
	LabelTitle.TextSize 	= TileUtils.TEXT_SIZE_TITLE
	LabelIcon.TextSize 		= TileUtils.TEXT_SIZE_ICON
	LabelIcon.TextColor 	= TileUtils.COLOR_TEXT_PRIMARY
	LabelValue.TextColor	= TileUtils.COLOR_TEXT_PRIMARY
	LabelValue.TextSize		= TileUtils.TEXT_SIZE_LABEL

	Dim state As Int = TileUtils.StateStyleToState(tilestate)
	Select state
		Case TileUtils.TILE_STATE_NORMAL
			LabelValue.TextSize = TileUtils.TEXT_SIZE_LABEL
			LabelValue.TextColor = TileUtils.TILE_COLOR_NORMAL_TEXT
			mBase.Color = TileUtils.TILE_COLOR_NORMAL_BACKGROUND

		Case TileUtils.TILE_STATE_WARNING
			LabelValue.TextSize = TileUtils.TEXT_SIZE_LABEL
			LabelValue.TextColor = TileUtils.TILE_COLOR_WARNING_TEXT
			mBase.Color = TileUtils.TILE_COLOR_WARNING_BACKGROUND

		Case TileUtils.TILE_STATE_ALARM
			LabelValue.TextSize = TileUtils.TEXT_SIZE_LABEL
			LabelValue.TextColor = TileUtils.TILE_COLOR_ALARM_TEXT
			mBase.Color = TileUtils.TILE_COLOR_ALARM_BACKGROUND

		Case TileUtils.TILE_STATE_DISABLED
			LabelValue.TextSize = TileUtils.TEXT_SIZE_LABEL
			LabelValue.TextColor = TileUtils.TILE_COLOR_DISABLED_TEXT
			mBase.Color = TileUtils.TILE_COLOR_DISABLED_BACKGROUND
	End Select
	
	mBase.SetColorAndBorder(TileUtils.COLOR_BACKGROUND_TILE_DEFAULT, _
	                           TileUtils.TILE_BORDER_WIDTH, _ 
							   TileUtils.COLOR_STATE_ON_BORDER, _ 
							   TileUtils.TILE_BORDER_RADIUS)
End Sub
#End Region
