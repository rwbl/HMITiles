﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10.3
@EndOfDesignText@
#Region Class Header
' ================================================================
' File: 	TileUtils.bas
' Brief:	Common constants and helper subs used by the customview tiles.
' Note:		https://www.b4x.com/android/forum/threads/b4x-custom-views-with-enhanced-designer-support.62488/
' ================================================================
#End Region

Sub Process_Globals
	' Colors
	' ================================================================
	' homekit32 Tile / HMI Colors
	' ================================================================

	' Default app background should be neutral, dark, and not too saturated.
	' See constants
	Public Const COLOR_PAGE_BACKGROUND As Int	= 0xFF1E2A38  ' Charcoal Blue

	' Default background color for tiles (neutral HMI blue)
	Public Const COLOR_TILE_DEFAULT       As Int = 0xFF4682B4  ' Steel Blue

	' Text / icon color on default tiles
	Public Const COLOR_TILE_TEXT_DEFAULT  As Int = 0xFFFFFFFF  ' White

	' Border color for tiles (slightly darker than background)
	Public Const COLOR_TILE_BORDER        As Int = 0xFF2C5D84  ' Dark Steel Blue

	' Warning state (amber/orange)
	Public Const COLOR_TILE_WARNING       As Int = 0xFFFFA000  ' Amber 600

	' Error state (red)
	Public Const COLOR_TILE_ERROR         As Int = 0xFFD32F2F  ' Red 600

	' Dimmed / inactive state (neutral gray)
	Public Const COLOR_TILE_DIMMED        As Int = 0xFF555555  ' Medium Gray

	' Active state for toggle buttons / switches (green)
	Public Const COLOR_TILE_ACTIVE        As Int = 0xFF2E7D32  ' Green 700

	' Inactive state for toggle buttons / switches (red)
	Public Const COLOR_TILE_INACTIVE      As Int = 0xFFB71C1C  ' Red 900

	' On/Off state for toggle buttons / switches (red/green)
	Public Const COLOR_TILE_STATE_ON As Int		= 0xFF2E7D32	' Green
	Public Const COLOR_TILE_STATE_OFF As Int	= 0xFFB71C1C	' Red
	Public Const COLOR_TEXT_INFO As Int			= 0xFFFFFFFF	' White
	Public Const COLOR_TEXT_WARNING As Int		= 0xFFFFA000	' Amber
	Public Const COLOR_TEXT_ERROR As Int		= 0xFFD32F2F	' Red

	' Icon colors (can override for specific tiles)
	Public Const COLOR_ICON_DEFAULT       As Int = 0xFFFFFFFF  ' White
	Public Const COLOR_ICON_WARNING       As Int = 0xFFFFA000  ' Amber
	Public Const COLOR_ICON_ERROR         As Int = 0xFFD32F2F  ' Red
	Public Const COLOR_ICON_DIMMED        As Int = 0xFFAAAAAA  ' Light Gray

	' Default border radius for all tiles
	Public Const TILE_BORDER_RADIUS As Double = 5

	' Default color for 2nd labels
	Public Const COLOR_LABEL_GRAY As Int = 0xFFB5C7D6  			' soft cool gray

	' Default padding
	Public Const TILE_PADDING As Int = 4dip

	' Byte converter - very useful
	Public ByteConv As ByteConverter
End Sub

'=============================================================================
' TILE HELPER
'=============================================================================
Public Sub SetStyleBold(node As Node, value As Boolean)
	If value Then
		CSSUtils.SetStyleProperty(node, "-fx-font-weight", "bold")
	Else
		CSSUtils.SetStyleProperty(node, "-fx-font-weight", "normal")
	End If
End Sub

Public Sub GetStyleBold(node As Node) As Boolean
	Dim property As String = CSSUtils.GetStyleProperty(node, "-fx-font-weight")
	Return property == "bold"
End Sub

Public Sub GetStyleBorderRadius(node As Node) As Double
	Dim s As String = CSSUtils.GetStyleProperty(node, "-fx-border-radius")
	If s.Length == 0 Then
		Return TILE_BORDER_RADIUS
	Else
		Return s
	End If
End Sub

'
' Conversions

'Convert a color hex string to int.
'The hex string must be 8. If length 6 then FF is set as prefix.
Public Sub HexToColor(hex As String) As Int	'ignore
	Dim bc As ByteConverter
	If hex.StartsWith("#") Then
		hex = hex.SubString(1)
	Else If hex.StartsWith("0x") Then
		hex = hex.SubString(2)
	End If
	If hex.Length == 6 Then hex = $"FF${hex}"$
	Dim b() As Byte = bc.HexToBytes(hex)
	Dim ints() As Int = bc.IntsFromBytes(b)
	Return ints(0)
End Sub

Public Sub CopyLabelProps(src As B4XView, dest As B4XView) As B4XView
	dest.Text = src.Text
	dest.Font = src.Font
	dest.Color = src.Color
	dest.TextColor = src.TextColor
	dest.TextSize = src.TextSize
	Return dest
End Sub

' Call like: ChangeButtonTextAnimated(TileButton1, newText)
Public Sub ChangeButtonTextAnimated(target As B4XView, newText As String)
	Dim duration As Int = 240
	' Fade out
	target.SetAlphaAnimated(duration, 0) ' duration in ms, alpha 0 = invisible
	Sleep(120)
	' Change text
	target.Text = newText
	' Fade back in
	target.SetAlphaAnimated(duration, 1) ' alpha 1 = fully visible
End Sub


