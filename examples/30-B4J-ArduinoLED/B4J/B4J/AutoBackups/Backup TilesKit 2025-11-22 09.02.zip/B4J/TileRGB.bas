﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=10.3
@EndOfDesignText@
#Region Class Header
' ================================================================
' File: 	TileRGB.bas
' Brief:	Tile to select RGB values (0..255), using seekbar with live color preview.
' Hints: 	Tile can not be resized after form loaded.
' Layout:
' Vertical
' +-----+
' |+-T-+|	< Label Title
' |+---+|
' |+RGB+|	< B4XSeekbar set color R,G,B
' |+---+|
' |+-P-+|	< Pane Preview
' +-----+
' Horizontal
' +-----+
' |+-T-+|	< Label Title
' |+---+|
' |+-R-+|	< B4XSeekbar set color R
' |+-G-+|	< B4XSeekbar set color G
' |+-B-+|	< B4XSeekbar set color B
' |+---+|
' |+-P-+|	< Pane Preview
' +-----+
' ================================================================
#End Region

' Properties
#DesignerProperty: Key: Vertical, DisplayName: Orientation Vertical, FieldType: Boolean, DefaultValue: False
#DesignerProperty: Key: TouchStateChanged, DisplayName: Use TouchState, FieldType: Boolean, DefaultValue: False, Description: Use touchstate released to trigger event instead every value change.

' Events
#Event: ValueChanged (m As Map)

Sub Class_Globals
	' Events
	Private mEventName As String
	Private mCallBack As Object

	' Base
	Public mBase As B4XView
	Public mLbl As B4XView
	Public Tag As Object

	' UI
	Private xui As XUI
	Private LabelTitle As B4XView
	Private PanePreview As B4XView
	Private B4XSeekBarRed As B4XSeekBar
    Private B4XSeekBarGreen As B4XSeekBar
    Private B4XSeekBarBlue As B4XSeekBar
    Private LabelValueRed As B4XView
    Private LabelValueGreen As B4XView
    Private LabelValueBlue As B4XView

	' Properties (designer)
	Private mTileBackgroundColor As Int
	Private mTileBorderColor As Int
	Private mTileBorderWidth As Int
	Private mTileBorderRadius As Double
	Private mTileTextStyleBold As Boolean
	Private mEnabled As Boolean = True
	Private mVertical As Boolean
	Private mTouchStateChanged As Boolean

	' Class lcals
	Private mR, mG, mB As Int
End Sub

Public Sub Initialize (Callback As Object, EventName As String)
    mCallBack = Callback
    mEventName = EventName
End Sub

Public Sub DesignerCreateView (Base As Object, Lbl As Label, Props As Map)
	mBase = Base
	' Capture the designer properties to class vars - prior assigning me to mbase.Tag
	mTileBackgroundColor = mBase.Color
	mLbl = Lbl

	' Store designer-provided style
	Dim p As Pane = mBase
	mTileBorderWidth = CSSUtils.GetStyleProperty(p, "-fx-border-width")
	mTileBorderRadius = TileUtils.GetStyleBorderRadius(p)
	mTileBorderColor = TileUtils.HexToColor(CSSUtils.GetStyleProperty(p, "-fx-border-color"))
	mTileTextStyleBold = TileUtils.GetStyleBold(Lbl)

	Tag = mBase.Tag
	mBase.Tag = Me

	CallSubDelayed2(Me, "AfterLoadLayout", Props)
End Sub

Sub AfterLoadLayout(Props As Map)	'ignore
	mBase.LoadLayout("TileRGB")

	' Set label title properties
	LabelTitle = TileUtils.CopyLabelProps(mLbl, LabelTitle)
	TileUtils.SetStyleBold(LabelTitle, mTileTextStyleBold)

	' Default values
	B4XSeekBarRed.Value = 0
	B4XSeekBarGreen.Value = 0
	B4XSeekBarBlue.Value = 0

	' Set the label value text color to gray
	LabelValueRed.TextColor = TileUtils.COLOR_LABEL_GRAY
	LabelValueGreen.TextColor = TileUtils.COLOR_LABEL_GRAY
	LabelValueBlue.TextColor = TileUtils.COLOR_LABEL_GRAY

	' Designer properties
	mVertical = Props.Get("Vertical")
	mTouchStateChanged = Props.Get("TouchStateChanged")
	
	ApplyColors
	ApplyTileBorder
	
	' Resize to get the sizing right
	Base_Resize(mBase.Width, mBase.Height)
End Sub

Private Sub Base_Resize (Width As Double, Height As Double)
	If mVertical Then
		VerticalBaseResize (Width, Height)
	Else
		HorizontalBaseResize (Width, Height)
	End If
End Sub

#Region VerticalBaseResize
Private Sub VerticalBaseResize(Width As Double, Height As Double)
	If Not(B4XSeekBarRed.IsInitialized) Then Return

	' Layout strategy:
	' Title Label = top + borderwidth + 4dip
	' Preview box = bottom 8%
	' Each slider row = (remaining space / 3) * 0.7

	Dim pad As Int = mTileBorderWidth + 4dip
	Dim previewH As Double = Height * 0.08

	' --- Title Label ---
	LabelTitle.SetLayoutAnimated(0, pad, pad, Width - pad*2, Height * 0.25)

	' --- Preview Pane ---
	Dim y As Double = Height - previewH - (pad * 0.5)
	PanePreview.SetLayoutAnimated(0, 5, y, Width - 10, previewH)
	Dim previewTop As Double = Height - previewH

	' --- Sliders area between title and preview ---
	Dim slidersTop As Double = LabelTitle.Top + LabelTitle.Height - 4dip
	Dim slidersHeight As Double = previewTop - slidersTop
	If slidersHeight < 0 Then slidersHeight = 0

	' Three equal columns: R G B
	Dim colW As Double = Width / 3

	VerticalLayoutSliderColumn(B4XSeekBarRed,   LabelValueRed,   0 * colW, colW, slidersTop, slidersHeight)
	VerticalLayoutSliderColumn(B4XSeekBarGreen, LabelValueGreen, 1 * colW, colW, slidersTop, slidersHeight)
	VerticalLayoutSliderColumn(B4XSeekBarBlue,  LabelValueBlue,  2 * colW, colW, slidersTop, slidersHeight)

	UpdateUI
End Sub

Private Sub VerticalLayoutSliderColumn(Bar As B4XSeekBar, ValueLabel As B4XView, Left As Double, ColumnWidth As Double, Top As Double, ColumnHeight As Double)
	Dim padding As Int = 2dip
	Dim valueLabelH As Int = 8dip

	' ----- Value Label (numeric) -----
	ValueLabel.TextSize = 11
	ValueLabel.SetLayoutAnimated(0, Left + padding, Top + padding, ColumnWidth - padding*2, valueLabelH)
	ValueLabel.SetTextAlignment("CENTER", "CENTER")

	' ----- Vertical Slider -----
	Dim sliderTop As Int = Top + padding + valueLabelH + padding
	Dim sliderHeight As Int = ColumnHeight - (valueLabelH + padding*3)
	If sliderHeight < 0 Then sliderHeight = 0

	Bar.mBase.SetLayoutAnimated(0, Left + padding, sliderTop, ColumnWidth - padding*2, sliderHeight)
	Bar.Radius2 = Bar.Radius1 * 1.1
End Sub
#End Region

#Region HorizontalBaseResize
Private Sub HorizontalBaseResize(Width As Double, Height As Double)
    If Not(B4XSeekBarRed.IsInitialized) Then Return

    ' Layout strategy:
	' Title Label = top + borderwidth + 4dip
    ' Preview box = bottom 8%
    ' Each slider row = (remaining space / 3) * 0.7

	Dim pad As Int = mTileBorderWidth + 4dip
	Dim previewH As Double = Height * 0.08
    Dim rowH As Double = ((Height - previewH) / 3) * 0.7

	' --- Title Label ---
	LabelTitle.SetLayoutAnimated(0, pad, pad, Width - pad*2, Height * 0.25)

	' --- Preview Pane ---
	Dim y As Double = Height - previewH - (pad * 0.5)
	PanePreview.SetLayoutAnimated(0, 5, y, Width - 10, previewH)

    ' --- Row 1: Red ---
    y = LabelTitle.Height
	HorizontalLayoutSliderRow(B4XSeekBarRed, LabelValueRed, y, rowH, Width)
    y = y + rowH

    ' --- Row 2: Green ---
	HorizontalLayoutSliderRow(B4XSeekBarGreen, LabelValueGreen, y, rowH, Width)
    y = y + rowH

    ' --- Row 3: Blue ---
	HorizontalLayoutSliderRow(B4XSeekBarBlue, LabelValueBlue, y, rowH, Width)

    UpdateUI
End Sub

Private Sub HorizontalLayoutSliderRow(Bar As B4XSeekBar, ValueLabel As B4XView, Top As Double, RowHeight As Double, Width As Double)
	Dim padding As Int = 6dip
	Dim labelW As Int = 40dip   ' right aligned numeric value
	Dim barW As Int = Width - labelW - padding*2

	Bar.mBase.SetLayoutAnimated(0, padding, Top + padding, barW, RowHeight - padding*2)
	ValueLabel.SetLayoutAnimated(0, barW + padding, Top, labelW, RowHeight)
End Sub
#End Region

Private Sub UpdateUI
    mR = B4XSeekBarRed.Value
    mG = B4XSeekBarGreen.Value
    mB = B4XSeekBarBlue.Value

    LabelValueRed.Text = mR
    LabelValueGreen.Text = mG
    LabelValueBlue.Text = mB

    PanePreview.Color = xui.Color_RGB(mR, mG, mB)

	If Not(mTouchStateChanged) Then
		ValueChanged(mR, mG, mB)
	End If
End Sub

' Optional getters
Public Sub getRed As Int
    Return mR
End Sub

Public Sub getGreen As Int
    Return mG
End Sub

Public Sub getBlue As Int
    Return mB
End Sub

Private Sub ApplyTileBorder
	mBase.SetColorAndBorder(mTileBackgroundColor, mTileBorderWidth, mTileBorderColor, mTileBorderRadius)
End Sub

Private Sub ApplyColors
	' RED
	B4XSeekBarRed.Color1 = 0x44FF0000
	B4XSeekBarRed.Color2 = 0xAAFF0000
	B4XSeekBarRed.ThumbColor = 0xFFFF0000

	' GREEN
	B4XSeekBarGreen.Color1 = 0x4400FF00
	B4XSeekBarGreen.Color2 = 0xAA00FF00
	B4XSeekBarGreen.ThumbColor = 0xFF00FF00

	' BLUE
	B4XSeekBarBlue.Color1 = 0x440000FF
	B4XSeekBarBlue.Color2 = 0xAA0000FF
	B4XSeekBarBlue.ThumbColor = 0xFF0000FF
End Sub

' Properties
Public Sub setEnabled(enabled As Boolean)
	mBase.Enabled = enabled
	mEnabled = mBase.Enabled
	If enabled Then
		mBase.Alpha = 1
	Else
		mBase.Alpha = 0.4
	End If
End Sub

Public Sub getEnabled As Boolean
	Return mEnabled
End Sub

' Seekbar value changes
' Update UI and trigger event.
Private Sub B4XSeekBarRed_ValueChanged (Value As Int)
	UpdateUI
End Sub

Private Sub B4XSeekBarGreen_ValueChanged (Value As Int)
	UpdateUI
End Sub

Private Sub B4XSeekBarBlue_ValueChanged (Value As Int)
	UpdateUI
End Sub

' Event triggered by seekbar value changes
Private Sub ValueChanged(R As Int, G As Int, B As Int)
	Dim m As Map = CreateMap("r":R, "g":G, "b":B)
	' Log($"[TileRGB.ValueChanged] ${m}, callback=${mCallBack}, eventname=${mEventName}"$)
	If SubExists(mCallBack, mEventName & "_ValueChanged") Then
		CallSub2(mCallBack, mEventName & "_ValueChanged", m)
	End If
End Sub

Private Sub B4XSeekBarRed_TouchStateChanged (Pressed As Boolean)
	If mTouchStateChanged Then
		If Not(Pressed) Then
			ValueChanged(mR, mG, mB)
		End If
	End If
End Sub

Private Sub B4XSeekBarGreen_TouchStateChanged (Pressed As Boolean)
	If mTouchStateChanged Then
		If Not(Pressed) Then
			ValueChanged(mR, mG, mB)
		End If
	End If
End Sub

Private Sub B4XSeekBarBlue_TouchStateChanged (Pressed As Boolean)
	If mTouchStateChanged Then
		If Not(Pressed) Then
			ValueChanged(mR, mG, mB)
		End If		
	End If
End Sub