﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=10.3
@EndOfDesignText@
#Region Class Header
' ================================================================
' File:     TileReadout.bas
' Brief:    Tile with a title and a big value+unit readout.
'           Supports Normal, Warning, Error, Dimmed styles.
' Layout:
'+------------------+
'|      Label       |   <- center, font size 15
'|       23         |   <- large, font size 2x label
'|       °C         |   <- small, font size 0.5–0.7x value
'+------------------+
' ================================================================
#End Region

' Designer Properties
#DesignerProperty: Key: TitleText, 	DisplayName: Title, FieldType: String, DefaultValue: Sensor
#DesignerProperty: Key: ValueText, 	DisplayName: Value, FieldType: String, DefaultValue: --
#DesignerProperty: Key: ValueScale, DisplayName: Value Text Scale, FieldType: Float, DefaultValue: 2.0
#DesignerProperty: Key: UnitText, 	DisplayName: Unit, FieldType: String, DefaultValue: Unit
#DesignerProperty: Key: UnitScale,	DisplayName: Unit Text Scale, FieldType: Float, DefaultValue: 0.8
#DesignerProperty: Key: TypeStyle,	DisplayName: Tile Style, FieldType: String, List: Normal|Warning|Error|Dimmed, DefaultValue: Normal

' Events
#Event: Click(EventData As MouseEvent)

Sub Class_Globals
	' Events
	Private mEventName As String
	Private mCallBack As Object

	' Base Views
	Public mBase As B4XView
	Public mLbl As B4XView
	Public Tag As Object

	' UI
	Private xui As XUI
	Private LabelTitle As B4XView
	Private LabelValue As B4XView
	Private LabelUnit As B4XView

	' Designer properties
	Private mTitleText As String
	Private mValueText As String
	Private mValueScale As Float			' multiplier for label value text size (center)
	Private mUnitText As String
	Private mUnitScale As Float				' multiplier for label unit text size (bottom)
	Private mTileBackgroundColor As Int
	Private mTileBorderColor As Int
	Private mTileBorderWidth As Int
	Private mTileBorderRadius As Double
	Private mTileTextStyleBold As Boolean
	Private mTypeStyle As String
	Private mEnabled As Boolean = True

	' Internal / fixed properties
End Sub

Public Sub Initialize (Callback As Object, EventName As String)
	mEventName = EventName
	mCallBack = Callback
End Sub

Public Sub DesignerCreateView (Base As Object, Lbl As Label, Props As Map)
	mBase = Base
	' Store designer-provided style
	mTileBackgroundColor = mBase.Color
	mLbl = Lbl

	Dim p As Pane = mBase
	mTileBorderWidth = CSSUtils.GetStyleProperty(p, "-fx-border-width")
	mTileBorderRadius = TileUtils.GetStyleBorderRadius(p)
	mTileBorderColor = TileUtils.HexToColor(CSSUtils.GetStyleProperty(p, "-fx-border-color"))
	mTileTextStyleBold = TileUtils.GetStyleBold(Lbl)
	mTypeStyle = Props.Get("TypeStyle")

	' Store designer properties
	mTitleText 	= Props.Get("TitleText")
	mValueText 	= Props.Get("ValueText")
	mValueScale	= Props.Get("ValueScale")
	mUnitText  	= Props.Get("UnitText")
	mUnitScale	= Props.Get("UnitScale")

	Tag = mBase.Tag
	mBase.Tag = Me

	CallSubDelayed2(Me, "AfterLoadLayout", Props)
End Sub

Private Sub AfterLoadLayout(Props As Map)	'ignore
	mBase.LoadLayout("TileReadout") ' You need a layout with two labels: Title + Value

	' Set label title properties
	LabelTitle = TileUtils.CopyLabelProps(mLbl, LabelTitle)
	LabelTitle.Text = mTitleText
	TileUtils.SetStyleBold(LabelTitle, mTileTextStyleBold)

	' Set label value properties
	LabelValue = TileUtils.CopyLabelProps(mLbl, LabelValue)
	LabelValue.Text = mValueText
	LabelValue.TextSize = LabelTitle.TextSize * mValueScale
'	LabelValue.Color = xui.Color_Transparent
'	LabelValue.TextColor = LabelTitle.TextColor
	TileUtils.SetStyleBold(LabelValue, True)

	' Set label unit properties
	LabelUnit = TileUtils.CopyLabelProps(mLbl, LabelUnit)
	LabelUnit.Text = mUnitText
	LabelUnit.TextSize = LabelTitle.TextSize * mUnitScale
	TileUtils.SetStyleBold(LabelUnit, mTileTextStyleBold)

	' Apply style
	Select mTypeStyle
		Case "Normal"
		Case "Warning"
			LabelTitle.TextColor = TileUtils.COLOR_TEXT_WARNING
			LabelValue.TextColor = LabelTitle.TextColor
			LabelUnit.TextColor = LabelTitle.TextColor
		Case "Error"
			LabelTitle.TextColor = TileUtils.COLOR_TEXT_ERROR
			LabelValue.TextColor = LabelTitle.TextColor
			LabelUnit.TextColor = LabelTitle.TextColor
		Case "Dimmed"
			LabelTitle.TextColor = xui.Color_DarkGray
			LabelValue.TextColor = LabelTitle.TextColor
			LabelUnit.TextColor = LabelTitle.TextColor
	End Select

	ApplyTileBorder
	Base_Resize(mBase.Width, mBase.Height)
End Sub

Private Sub Base_Resize(Width As Double, Height As Double)
	If Not(LabelTitle.IsInitialized) Or Not(LabelValue.IsInitialized) Then Return

	Dim pad As Int = mTileBorderWidth + 4dip
	
	LabelTitle.SetLayoutAnimated(0, pad, pad, Width - pad*2, Height * 0.25)
	LabelValue.SetLayoutAnimated(0, pad, Height*0.25, Width - pad*2, Height*0.60)
	LabelUnit.SetLayoutAnimated(0, pad, Height*0.80, Width - pad*2, Height*0.15)
End Sub

' ========== Getters / Setters ==========

Public Sub setTitle(text As String)
	LabelTitle.Text = text
End Sub
Public Sub getTitle As String
	Return LabelTitle.Text
End Sub

Public Sub setValue(value As String)
	LabelValue.Text = value
End Sub
Public Sub getValue As String
	Return LabelValue.Text
End Sub

Public Sub setTileColor(value As Int)
	mBase.Color = value
End Sub
Public Sub getTileColor As Int
	Return mBase.Color
End Sub

Public Sub setTextColor(value As Int)
	LabelTitle.TextColor = value
	LabelValue.TextColor = value
End Sub
Public Sub getTextColor As Int
	Return LabelTitle.TextColor
End Sub

Public Sub setEnabled(enabled As Boolean)
	mBase.Enabled = enabled
	mEnabled = mBase.Enabled
	If enabled Then
		mBase.Alpha = 1
	Else
		mBase.Alpha = 0.4
	End If
End Sub
Public Sub getEnabled As Boolean
	Return mEnabled
End Sub

Public Sub SetStateColor(success As Boolean)
	If success Then
		mTileBackgroundColor = 0xFF2E7D32
	Else
		mTileBackgroundColor = 0xFFB71C1C
	End If
	ApplyTileBorder
End Sub

Private Sub ApplyTileBorder
	mBase.SetColorAndBorder(mTileBackgroundColor, mTileBorderWidth, mTileBorderColor, mTileBorderRadius)
End Sub

Private Sub LabelValue_MouseClicked (EventData As MouseEvent)
	' Log($"[TileReadOut] LabelValue_MouseClicked mcallback=${mCallback}, meventname=${meventname}"$)
	If SubExists(mCallBack, mEventName & "_Click") Then
		CallSub2(mCallBack, mEventName & "_Click", EventData)
	End If
End Sub
