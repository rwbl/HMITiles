﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=10.3
@EndOfDesignText@
#Region Class Header
' ================================================================
' File:     TileDigitalClock.bas
' Brief:    A digital clock tile (HH:MM or HH:MM:SS)
' Notes:    Very similar to TileLabel, but automatically updates
' ================================================================
#End Region

#DesignerProperty: Key: ShowSeconds, DisplayName: Show Seconds, FieldType: Boolean, DefaultValue: False
#DesignerProperty: Key: BlinkColon, DisplayName: Blink Colon, FieldType: Boolean, DefaultValue: False
#DesignerProperty: Key: TypeStyle, DisplayName: Tile Style, FieldType: String, List: Normal|Warning|Error|Dimmed, DefaultValue: Normal

#Event: Click(EventData As MouseEvent)

Sub Class_Globals
	Private xui As XUI

	Public mBase As B4XView
	Private mLbl As B4XView
	Public Tag As Object

	Private mEventName As String
	Private mCallBack As Object

	Private LabelText As B4XView

	Private mTileBorderWidth As Int
	Private mTileBorderColor As Int
	Private mTileBorderRadius As Double
	Private mTileBackgroundColor As Int
	Private mTileTextStyleBold As Boolean
	Private mTypeStyle As String

	Private TimerClock As Timer
	Private ClockBlink As Boolean
	Private ShowSec As Boolean
	Private DoBlink As Boolean
End Sub

Public Sub Initialize(Callback As Object, EventName As String)
	mEventName = EventName
	mCallBack = Callback
	TimerClock.Initialize("TimerClock", 1000)
End Sub

Public Sub DesignerCreateView(Base As Object, Lbl As Label, Props As Map)
	mBase = Base
	' Capture the designer properties to class vars - prior assigning me to mbase.Tag
	mTileBackgroundColor = mBase.Color
	mLbl = Lbl
	
	' Read border color/width from designer
	Dim p As Pane = mBase
	mTileBorderWidth = CSSUtils.GetStyleProperty(p, "-fx-border-width")
	mTileBorderRadius = TileUtils.GetStyleBorderRadius(p)
	mTileBorderColor = TileUtils.HexToColor(CSSUtils.GetStyleProperty(p, "-fx-border-color"))
	mTileTextStyleBold = TileUtils.GetStyleBold(Lbl)
	mTileBackgroundColor = mBase.Color
	TileUtils.SetStyleBold(mLbl, True)

	' Set tag
	Tag = mBase.Tag
	mBase.Tag = Me

	' Load the customview layout(s) via CallSubDelayed.
	CallSubDelayed2(Me, "AfterLoadLayout", Props)
End Sub

Sub AfterLoadLayout(Props As Map)
	mBase.LoadLayout("TileLabel")

	' Assign the label properties to the LabelText
	LabelText = TileUtils.CopyLabelProps(mLbl, LabelText)
	TileUtils.SetStyleBold(LabelText, mTileTextStyleBold)
	ShowSec = Props.Get("ShowSeconds")
	DoBlink = Props.Get("BlinkColon")
	mTypeStyle = Props.Get("TypeStyle")

	' Set special tile types
	Select mTypeStyle
		Case "Normal"
			' These are set previous
		Case "Warning"
			LabelText.TextColor = 0xFFFFA000   ' Amber
		Case "Error"
			LabelText.TextColor = 0xFFD32F2F   ' Red 600
		Case "Dimmed"
			LabelText.TextColor = xui.Color_DarkGray
	End Select

	ApplyTileBorder

	' Resize to get the sizing right
	Base_Resize(mBase.Width, mBase.Height)
	
	StartClock
End Sub

Public Sub Base_Resize (Width As Double, Height As Double)
	mLbl.SetLayoutAnimated(0, 0, 0, Width, Height)
End Sub

Private Sub ApplyTileBorder
	mBase.SetColorAndBorder(mTileBackgroundColor, mTileBorderWidth, mTileBorderColor, mTileBorderRadius)
End Sub

#Region Clock
Private Sub StartClock
	TimerClock.Enabled = True
End Sub

Private Sub TimerClock_Tick
	UpdateClock
End Sub

Private Sub UpdateClock
	Dim now As Long = DateTime.Now
	Dim h As Int = DateTime.GetHour(now)
	Dim m As Int = DateTime.GetMinute(now)
	Dim s As Int = DateTime.GetSecond(now)

	Dim colon As String = ":"
	If DoBlink Then
		If ClockBlink = False Then colon = " "
		ClockBlink = Not(ClockBlink)
	End If

	Dim txt As String
	If ShowSec Then
		txt = NumberFormat2(h, 2, 0, 0, False) & colon & NumberFormat2(m, 2, 0, 0, False) & colon & NumberFormat2(s, 2, 0, 0, False)
	Else
		txt = NumberFormat2(h, 2, 0, 0, False) & colon & NumberFormat2(m, 2, 0, 0, False)
	End If

	' mLbl.Text = txt
	LabelText.Text = txt
End Sub

#End Region

Private Sub LabelText_MouseClicked (EventData As MouseEvent)
	If SubExists(mCallBack, mEventName & "_Click") Then
		CallSub2(mCallBack, mEventName & "_Click", EventData)
	End If
End Sub

