﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=10.3
@EndOfDesignText@
#Region Class Header
' ================================================================
' File: 	TileSensor.bas
' Brief:	Tile with at the 
'			- top an icon/label centered
'			- bottom a label with value
'			Style can be set to Normal, Warning, Error or Dimmed.
' Hints: 	Tile can not be resized after form loaded.
' 			DesignerProperty FieldType - One of the following values (case insensitive): String, Int, Float, Boolean or Color.
' Layout:
'+------------------+
'|       Label      |  (top-aligned Or centered)
'|       Icon       |  (midlle centered)
'| Sensor Value Unit|  (center Or bottom)
'+------------------+
' ================================================================
#End Region

#Region Class Header
' ================================================================
' File:     TileSensor.bas
' Brief:    Tile for displaying sensor information.
'           Supports Title + Icon + Value with Style colors.
' ================================================================
#End Region

' Designer properties
#DesignerProperty: Key: TitleText, DisplayName: Title, FieldType: String, DefaultValue: Sensor
#DesignerProperty: Key: ValueText, DisplayName: Value, FieldType: String, DefaultValue: --
#DesignerProperty: Key: UnitText,  DisplayName: Unit,  FieldType: String, DefaultValue: 
#DesignerProperty: Key: Icon,      DisplayName: Icon (FontAwesome), FieldType: String, DefaultValue: 
#DesignerProperty: Key: IconScale, DisplayName: Icon Scale, FieldType: Float, DefaultValue: 2.0
#DesignerProperty: Key: TypeStyle, DisplayName: Tile Style, FieldType: String, List: Normal|Warning|Error|Dimmed, DefaultValue: Normal

#Event: Click(EventData As MouseEvent)

Sub Class_Globals
	Private mEventName As String
	Private mCallBack As Object

	Public mBase As B4XView
	Public mLbl As B4XView     ' from designer

	Private xui As XUI
	Public Tag As Object

	' Views inside TileSensor.bjl
	Private LabelTitle As B4XView
	Private LabelIcon As B4XView
	Private LabelValue As B4XView

	' Designer values
	Private mTileBackgroundColor As Int
	Private mTileBorderColor As Int
	Private mTileBorderRadius As Double
	Private mTileBorderWidth As Int
	Private mTileTextStyleBold As Boolean	'ignore
	Private mTypeStyle As String

	Private mTitleText As String
	Private mValueText As String
	Private mUnitText As String
	Private mIcon As String
	Private mIconScale As Float
	Private mEnabled As Boolean = True
End Sub


Public Sub Initialize(Callback As Object, EventName As String)
	mEventName = EventName
	mCallBack = Callback
End Sub


Public Sub DesignerCreateView(Base As Object, Lbl As Label, Props As Map)
	mBase = Base
	mLbl = Lbl

	' Store designer-provided style
	mTileBackgroundColor = mBase.Color
	Dim p As Pane = mBase
	mTileBorderWidth = CSSUtils.GetStyleProperty(p, "-fx-border-width")
	mTileBorderRadius = TileUtils.GetStyleBorderRadius(p)
	mTileBorderColor = TileUtils.HexToColor(CSSUtils.GetStyleProperty(p, "-fx-border-color"))
	mTileTextStyleBold = TileUtils.GetStyleBold(Lbl)
	mTypeStyle = Props.Get("TypeStyle")

	' Store designer properties
	mTitleText 	= Props.Get("TitleText")
	mValueText 	= Props.Get("ValueText")
	mUnitText  	= Props.Get("UnitText")
	mIcon      	= Props.Get("Icon")
	mIconScale	= Props.Get("IconScale")
	' Log($"mIcon=${mIcon}, ${Bit.ParseInt(mIcon, 16)}, ${Chr(Bit.ParseInt(mIcon, 16))}, ${mIconScale}"$)

	Tag = mBase.Tag
	mBase.Tag = Me

	CallSubDelayed2(Me, "AfterLoadLayout", Props)
End Sub

Private Sub AfterLoadLayout(Props As Map)	'ignore
	mBase.LoadLayout("TileSensor")

	' Copy style from the template Label
	LabelTitle = TileUtils.CopyLabelProps(mLbl, LabelTitle)
	' TileUtils.CopyLabelProps(mLbl, LabelIcon)
	LabelValue = TileUtils.CopyLabelProps(mLbl, LabelValue)

	LabelTitle.Text = mTitleText
	LabelIcon.Text  = mIcon
	LabelIcon.TextSize = LabelTitle.TextSize * mIconScale
	LabelIcon.TextColor = mLbl.TextColor
	LabelValue.Text = mValueText & mUnitText

	TileUtils.SetStyleBold(LabelTitle, True)
	TileUtils.SetStyleBold(LabelValue, True)

	' Ensure the font is set to FA
	SetIcon(mIcon)

	Select mTypeStyle
		Case "Warning" : LabelValue.TextColor = 0xFFFFA000
		Case "Error"   : LabelValue.TextColor = 0xFFD32F2F
		Case "Dimmed"  : LabelValue.TextColor = xui.Color_DarkGray
	End Select
	
	ApplyTileBorder
	Base_Resize(mBase.Width, mBase.Height)
End Sub

Private Sub Base_Resize(Width As Double, Height As Double)
	If Not(LabelValue.IsInitialized) Then Return

	Dim pad As Int = mTileBorderWidth + 4dip

	LabelTitle.SetLayoutAnimated(0, pad, pad, Width - pad*2, Height * 0.25)
	LabelIcon.SetLayoutAnimated(0, pad, Height*0.25, Width - pad*2, Height*0.30)
	LabelValue.SetLayoutAnimated(0, pad, Height*0.55, Width - pad*2, Height*0.40)
End Sub


' ===================================================================
' Public API
' ===================================================================
' Title
Public Sub SetTitle(title As String)
	mTitleText = title
	LabelTitle.Text = title
End Sub

' Icon
Public Sub SetIcon(iconHex As String)
	If iconHex == "" Then Return

	' Log($"[SetIcon] iconHex=${iconHex}, ${Bit.ParseInt(iconHex, 16)}"$)

    ' expects "F043" or "f043" or real character
    Try
        If iconHex.Length > 0 And iconHex.Length <= 6 And iconHex.ToLowerCase.StartsWith("f") Then
            LabelIcon.Text = Chr(Bit.ParseInt(iconHex, 16))
        Else
            LabelIcon.Text = iconHex
        End If
    Catch
        LabelIcon.Text = iconHex
    End Try
End Sub

Public Sub SetIconColor(clr As Int)
    LabelIcon.TextColor = clr
End Sub

Public Sub SetIconSize(size As Int)
    LabelIcon.TextSize = size
End Sub

Public Sub SetIconScale(scale As Float)
	LabelIcon.TextSize = LabelTitle.TextSize * scale
End Sub

' Value
Public Sub SetValue(value As String)
	mValueText = value
	LabelValue.Text = value & mUnitText
End Sub

Public Sub SetUnit(unit As String)
	mUnitText = unit
	LabelValue.Text = mValueText & unit
End Sub

Public Sub SetStateColor(success As Boolean)
	If success Then
		mTileBackgroundColor = 0xFF2E7D32
	Else
		mTileBackgroundColor = 0xFFB71C1C
	End If
	ApplyTileBorder
End Sub

Public Sub setEnabled(enabled As Boolean)
	mEnabled = enabled
	mBase.Enabled = enabled
	mBase.Alpha = IIf(enabled, 1, 0.4)
End Sub

Public Sub getEnabled As Boolean
	Return mEnabled
End Sub

Private Sub ApplyTileBorder
	mBase.SetColorAndBorder(mTileBackgroundColor, mTileBorderWidth, mTileBorderColor, mTileBorderRadius)
End Sub

Private Sub LabelIcon_MouseClicked(EventData As MouseEvent)
	If SubExists(mCallBack, mEventName & "_Click") Then
		CallSub2(mCallBack, mEventName & "_Click", EventData)
	End If
End Sub
