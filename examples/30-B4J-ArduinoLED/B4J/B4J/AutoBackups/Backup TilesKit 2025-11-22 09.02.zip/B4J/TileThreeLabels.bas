﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=10.3
@EndOfDesignText@
#Region Class Header
' File: 	TileText.bas
' Brief:	Tile with header, text, footer
' Hints: 	Ensure to set the hor & vert anchors after adding to a layout 
' 			DesignerProperty FieldType - One of the following values (case insensitive): String, Int, Float, Boolean or Color.
' Layout:
' +-----+
' |+---+|
' || H ||
' |+---+|
' |+---+|
' || T ||
' |+---+|
' |+---+|
' || F ||
' |+---+|
#End Region

' Views
#DesignerProperty: Key: HeaderText, DisplayName: Header Text, FieldType: String, DefaultValue: Header, Description: Header text
#DesignerProperty: Key: HeaderTextColor, DisplayName: Header Text Color, FieldType: Color, DefaultValue: 0xFFFFFFFF, Description: Header Text color
#DesignerProperty: Key: HeaderTextSize, DisplayName: Header Text Size, FieldType: Int, List: 8|10|12|14|16|18|20, DefaultValue: 12, Description: Header text size
#DesignerProperty: Key: HeaderTextStyleBold, DisplayName: Header Text Bold, FieldType: Boolean, DefaultValue: False, Description: Header text bold or normal
#DesignerProperty: Key: ContentText, DisplayName: Content Text, FieldType: String, DefaultValue: Content, Description: Content text
#DesignerProperty: Key: ContentTextColor, DisplayName: Content Text Color, FieldType: Color, DefaultValue: 0xFFFFFFFF, Description: Content Text color
#DesignerProperty: Key: ContentTextSize, DisplayName: Content Text Size, FieldType: Int, List: 8|10|12|14|16|18|20, DefaultValue: 12, Description: Content text size
#DesignerProperty: Key: ContentTextStyleBold, DisplayName: Content Text Bold, FieldType: Boolean, DefaultValue: False, Description: Content text bold or normal
#DesignerProperty: Key: FooterText, DisplayName: Footer Text, FieldType: String, DefaultValue: Footer, Description: Footer text
#DesignerProperty: Key: FooterTextColor, DisplayName: Footer Text Color, FieldType: Color, DefaultValue: 0xFFFFFFFF, Description: Footer Text color
#DesignerProperty: Key: FooterTextSize, DisplayName: Footer Text Size, FieldType: Int, List: 8|10|12|14|16|18|20, DefaultValue: 12, Description: Footer text size
#DesignerProperty: Key: FooterTextStyleBold, DisplayName: Footer Text Bold, FieldType: Boolean, DefaultValue: False, Description: Footer text bold or normal
#DesignerProperty: Key: UsePropertySettings, DisplayName: Use Property Settings, FieldType: Boolean, DefaultValue: True, Description: Use the property settings for the header, content & footer

Sub Class_Globals
	Private mEventName As String 'ignore
	Private mCallBack As Object 'ignore
	Public mBase As B4XView
	Public mLbl As B4XView
	Private xui As XUI 'ignore
	Public Tag As Object
	
	Private LabelHeader As B4XView
	Private LabelContent As B4XView
	Private LabelFooter As B4XView

	'Properties
	Private mTileBackgroundColor As Int
	Private mTileBorderColor As Int
	Private mTileBorderWidth As Int
	Private mTileTextColor As Int
	Private mTileTextSize As Int
	Private mTileTextStyleBold As Boolean
	Private mUsePropertySettings As Boolean
End Sub

Public Sub Initialize (Callback As Object, EventName As String)
	mEventName = EventName
	mCallBack = Callback
End Sub

'Base type must be Object
Public Sub DesignerCreateView (Base As Object, Lbl As Label, Props As Map)
	mBase = Base
	' Capture the designer properties to class vars - prior assigning me to mbase.Tag
	mTileBackgroundColor = mBase.Color
	
	' Capture the designer properties label color	
	mLbl = Lbl
	mTileTextColor = mLbl.TextColor
	mTileTextSize = mLbl.TextSize
	
	Dim p As Pane = mBase
'	-fx-font-size:15.00;-fx-background-color:#008080;
'	-fx-border-color:#FF0000;
'	-fx-border-radius:3.00;-fx-background-radius:3.00;-fx-border-width:2.00;
'	-fx-font-size:15.00;-fx-background-color:#FFFFFF;
'	-fx-border-color:#0000FF;
'	-fx-border-width:4.00;
	mTileBorderWidth = CSSUtils.GetStyleProperty(p, "-fx-border-width")
	mTileBorderColor = HexToColor(CSSUtils.GetStyleProperty(p, "-fx-border-color"))
	mTileTextStyleBold = GetTextStyleBold(Lbl)
	
    Tag = mBase.Tag
    mBase.Tag = Me 

	mUsePropertySettings = Props.Get("UsePropertySettings")
	
	' Load the customview layout(s) via CallSubDelayed.
	CallSubDelayed2(Me, "AfterLoadLayout", Props)
End Sub

Sub AfterLoadLayout(Props As Map)	'ignore
	mBase.LoadLayout("TileThreeLabels")
	mBase.Color = mTileBackgroundColor
	mBase.SetColorAndBorder(mTileBackgroundColor, mTileBorderWidth, mTileBorderColor, 0)

	' Assign selected designer properties

	If mUsePropertySettings Then
		' Assign the base color to the labels background
		LabelHeader.Color = mTileBackgroundColor
		LabelHeader.TextColor = mTileTextColor
		LabelHeader.TextSize = mTileTextSize
		SetTextStyleBold(LabelHeader, mTileTextStyleBold)

		LabelContent.Color = mTileBackgroundColor
		LabelContent.TextColor = mTileTextColor
		LabelContent.TextSize = mTileTextSize
		SetTextStyleBold(LabelContent, mTileTextStyleBold)

		LabelFooter.Color = mTileBackgroundColor
		LabelFooter.TextColor = mTileTextColor
		LabelFooter.TextSize = mTileTextSize
		SetTextStyleBold(LabelFooter, mTileTextStyleBold)

	End If

	' Resite to get the sizing right
	Base_Resize(mBase.Width, mBase.Height)
End Sub

Private Sub Base_Resize (Width As Double, Height As Double)
	Dim offset As Int = mTileBorderWidth
	Dim heighttext As Int = Height - (offset*2)
	Dim labelwidth As Int = Width - (offset*2)
	Dim labelleft As Int = offset
	
	If LabelHeader.IsInitialized Then
		LabelHeader.Top = offset
		LabelHeader.Height = heighttext / 4
		LabelHeader.Width = labelwidth
		LabelHeader.Left = labelleft

		LabelContent.Top = LabelHeader.Top + LabelHeader.Height
		LabelContent.Height = heighttext / 2
		LabelContent.Width = labelwidth
		LabelContent.Left = labelleft

		LabelFooter.Top = LabelContent.Top + LabelContent.Height
		LabelFooter.Height = heighttext / 4
		LabelFooter.Width = labelwidth
		LabelFooter.Left = labelleft
	End If
End Sub

' Getter/Setter

Public Sub setTileColor(value As Int)
	mBase.Color = value
	LabelHeader.Color = mBase.Color
	LabelContent.Color = mBase.Color
	LabelFooter.Color = mBase.Color
End Sub
Public Sub getTileColor As Int
	Return mBase.Color
End Sub

Public Sub setTextColor(value As Int)
	LabelHeader.TextColor = value
	LabelContent.TextColor = value
	LabelFooter.TextColor = value
End Sub
Public Sub getTextColor As Int
	Return LabelHeader.Color
End Sub

Public Sub setHeaderText(text As String)
	LabelHeader.Text = text
End Sub
Public Sub getHeaderText As String
	Return LabelHeader.Text
End Sub

Public Sub setHeaderTextColor(value As Int)
	LabelHeader.TextColor = value
End Sub
Public Sub getHeaderTextColor As Int
	Return LabelHeader.TextColor
End Sub

Public Sub setHeaderTextSize(value As Int)
	LabelHeader.TextSize = value
End Sub
Public Sub getHeaderTextSize As Int
	Return LabelHeader.TextSize
End Sub

Public Sub setHeaderTextStyleBold(value As Boolean)
	SetTextStyleBold(LabelHeader, value)
End Sub
Public Sub getHeaderTextStyleBold As Boolean
	Return CSSUtils.GetStyleProperty(LabelHeader, "-fx-font-weight") == "bold"
End Sub

Public Sub setContentText(text As String)
	LabelContent.Text = text
End Sub
Public Sub getContentText As String
	Return LabelContent.Text
End Sub

Public Sub setContentTextColor(value As Int)
	LabelContent.TextColor = value
End Sub
Public Sub getContentTextColor As Int
	Return LabelContent.TextColor
End Sub

Public Sub setContentTextSize(value As Int)
	LabelContent.TextSize = value
End Sub
Public Sub getContentTextSize As Int
	Return LabelContent.TextSize
End Sub

Public Sub setContentTextStyleBold(value As Boolean)
	SetTextStyleBold(LabelContent, value)
End Sub
Public Sub getContentTextStyleBold As Boolean
	Return CSSUtils.GetStyleProperty(LabelContent, "-fx-font-weight") == "bold"
End Sub

Public Sub setFooterText(text As String)
	LabelFooter.Text = text
End Sub
Public Sub getFooterText As String
	Return LabelFooter.Text
End Sub

Public Sub setFooterTextColor(value As Int)
	LabelFooter.TextColor = value
End Sub
Public Sub getFooterTextColor As Int
	Return LabelFooter.TextColor
End Sub

Public Sub setFooterTextSize(value As Int)
	LabelFooter.TextSize = value
End Sub
Public Sub getFooterTextSize As Int
	Return LabelFooter.TextSize
End Sub

Public Sub setFooterTextStyleBold(value As Boolean)
	SetTextStyleBold(LabelFooter, value)
End Sub
Public Sub getFooterTextStyleBold As Boolean
	Return CSSUtils.GetStyleProperty(LabelFooter, "-fx-font-weight") == "bold"
End Sub

'=============================================================================
' HELPER
'=============================================================================

Private Sub SetTextStyleBold(node As Node, value As Boolean)
	If value Then
		CSSUtils.SetStyleProperty(node, "-fx-font-weight", "bold")
	Else
		CSSUtils.SetStyleProperty(node, "-fx-font-weight", "normal")
	End If
End Sub
Private Sub GetTextStyleBold(node As Node) As Boolean
	Dim property As String = CSSUtils.GetStyleProperty(node, "-fx-font-weight")
	Return property == "bold"
End Sub

'Convert a color hex string to int.
'The hex string must be 8. If length 6 then FF is set as prefix.
Private Sub HexToColor(hex As String) As Int	'ignore
	Dim bc As ByteConverter
	If hex.StartsWith("#") Then
		hex = hex.SubString(1)
	Else If hex.StartsWith("0x") Then
		hex = hex.SubString(2)
	End If
	If hex.Length == 6 Then hex = $"FF${hex}"$
	Dim b() As Byte = bc.HexToBytes(hex)
	Dim ints() As Int = bc.IntsFromBytes(b)
	Return ints(0)
End Sub
