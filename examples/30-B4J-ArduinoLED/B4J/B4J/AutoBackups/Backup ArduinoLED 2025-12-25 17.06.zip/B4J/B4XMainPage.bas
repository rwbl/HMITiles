﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=9.85
@EndOfDesignText@
#Region Class Header
' ================================================================
' File:			ArduinoLED
' Brief:		Control the state of an LED connected to an Arduino UNO via the serial line.
' Date:			2025-12-25
' Author:		Robert W.B. Linn (c) 2025 MIT
' Description:	The application connects to the Arduino UNO via the serial line (COM).
'				The state of the Arduino onboard LED (pin 0x0D) is set via byte 0x00 (OFF) or 0x01 (ON).
' Notes:		Ensure the B4R IDE is disconnected else the COM port is locked.
' ================================================================
#End Region

#Region Shared Files
#CustomBuildAction: folders ready, %WINDIR%\System32\Robocopy.exe,"..\..\Shared Files" "..\Files"
#End Region

Sub Class_Globals
	' ================================================================
	' APPLICATION METADATA
	' ================================================================
	Private VERSION As String	= "ArduinoLED v20251225"
	Private ABOUT As String 	= $"HMITiles Example ${VERSION} (c) 2025 Robert W.B. Linn - MIT"$

	' ================================================================
	' UI ROOT & CORE
	' ================================================================
	Private xui As XUI
	Private Root As B4XView
	Private LabelAbout As B4XView

	' ================================================================
	' TILES
	' ================================================================
	' Button to open the COM port
	Private TileButtonOpenPort As HMITileButton
	
	' Select COM port
	Private TileSelectPort As HMITileSelect
	Private TileSelectCommand As HMITileSelect

	' Button to toggle the LED on the Arduino
	Private TileButtonLEDControl As HMITileButton
	
	' Event / alarm viewer
	Private TileEvents As HMITileEventViewer
	
	' ================================================================
	' SERIAL COMMUNICATION ARDUINO
	' ================================================================
	Private SerialLine As Serial
	Private const BAUDRATE As Int = 115200
	Private PortSelected As String = ""
	Private IsPortOpen As Boolean = False
	Private AStream As AsyncStreams
End Sub

Public Sub Initialize
	' Enable lifecycle logging for debugging and learning
	B4XPages.GetManager.LogEvents = True
End Sub

' Called once when the page is created
Private Sub B4XPage_Created (Root1 As B4XView)
	Root = Root1
	Root.LoadLayout("MainPage")

	' ================================================================
	' SERIAL LINE
	' ================================================================
	SerialLine.Initialize("")

	' ================================================================
	' GENERAL UI SETTINGS
	' ================================================================
	Root.Color = HMITileUtils.COLOR_BACKGROUND_SCREEN
	B4XPages.SetTitle(Me, VERSION)
	B4XPages.GetNativeParent(Me).Resizable = False
	LabelAbout.Text = ABOUT

	' Allow CustomViews to fully initialize
	Sleep(1)

	' ================================================================
	' EVENT VIEWER
	' ================================================================
	TileEvents.CompactMode = False
	TileEvents.Insert(VERSION, HMITileUtils.EVENT_LEVEL_INFO)

	' ================================================================
	' BUTTONS
	' ================================================================
	TileButtonOpenPort.StateText = IIf(False, "Open", "Closed")
	TileButtonLEDControl.StateText = IIf(False, "ON", "OFF")

	' ================================================================
	' SELECT LIST
	' ================================================================
	TileSelectPort.AddAll(SerialLine.ListPorts)
	If SerialLine.ListPorts.Size < 3 Then
		TileSelectPort.Scrollbar = False
	End If
	If TileSelectPort.Size == 1 Then
		TileSelectPort.SetSelectedItem(0)
		PortSelected = TileSelectPort.SelectedItem
	End If

	TileSelectCommand.AddAll(Array As String("On", "Off", "Blink"))
End Sub

' ================================================================
' LED CONTROL BUTTON
' ================================================================
Private Sub TileButtonOpenPort_Click
	TileButtonOpenPort.SetState(TileButtonOpenPort.State)
	TileButtonOpenPort.StateText = IIf(TileButtonOpenPort.State, "Open", "Closed")
	TileEvents.Insert($"[TileButtonOpenPort] port=${PortSelected}, state=${TileButtonOpenPort.State}"$, HMITileUtils.EVENT_LEVEL_INFO)

	If AStream.IsInitialized Then
		AStream.Close
		SerialLine.Close
		IsPortOpen = False
	End If
	If PortSelected.Length == 0 Then Return
	
	If TileButtonOpenPort.State Then
		Try
			SerialLine.Open(PortSelected)
			SerialLine.SetParams(BAUDRATE, 8, 1, 0)
			AStream.Initialize(SerialLine.GetInputStream, SerialLine.GetOutputStream, "AStream")
			IsPortOpen = True
			TileEvents.Insert($"[TileButtonOpenPort] port=${PortSelected}, open=${IsPortOpen}"$, HMITileUtils.EVENT_LEVEL_INFO)			
		Catch
			IsPortOpen = True
			TileEvents.Insert($"[TileButtonOpenPort] port=${PortSelected}, open=${IsPortOpen}"$, HMITileUtils.EVENT_LEVEL_INFO)
		End Try
	End If
End Sub

Private Sub TileButtonLEDControl_Click
	If Not(IsPortOpen) Then Return
	Dim data(1) As Byte
	
	TileButtonLEDControl.SetState(TileButtonLEDControl.State)
	TileButtonLEDControl.StateText = IIf(TileButtonLEDControl.State, "ON", "OFF")
	TileEvents.Insert($"[TileButtonLEDControl] state=${TileButtonLEDControl.State}"$, HMITileUtils.EVENT_LEVEL_INFO)
	
	If TileButtonLEDControl.State Then
		data(0) = 0x01
	Else
		data(0) = 0x00
	End If
	AStreamWrite(data)
End Sub

Private Sub TileSelectCommand_ItemClick (Index As Int, Value As Object)
	If Not(IsPortOpen) Then Return
	Dim data(1) As Byte
	
	TileEvents.Insert($"[TileSelectCommand_ItemClick] index=${Index}, value=${Value}"$, HMITileUtils.EVENT_LEVEL_INFO)
	Select Index
		Case 0
			data(0) = 0x01
		Case 1
			data(0) = 0x00
		Case 2
			data(0) = 0x02
	End Select
	AStreamWrite(data)
End Sub

' ================================================================
' EVENT VIEWER & TILE CALLBACKS
' ================================================================
Private Sub TileEvents_ItemClick (Index As Int, Value As Object)
	TileEvents.Insert($"[TileEvents_ItemClick] index=${Index}, value=${Value}"$, _
		HMITileUtils.EVENT_LEVEL_INFO)
End Sub

Private Sub TileSelect_ItemClick (Index As Int, Value As Object)
	TileEvents.Insert($"[TileSelect_ItemClick] index=${Index}, value=${Value}"$, _
		HMITileUtils.EVENT_LEVEL_INFO)
	PortSelected = Value.As(String)
End Sub

' ================================================================
' ASYNCSTREAM
' ================================================================
Sub AStream_NewData (Buffer() As Byte)
	TileEvents.Insert($"[AStream_NewData] data=${HMITileUtils.ByteConv.HexFromBytes(Buffer)}"$, _
		HMITileUtils.EVENT_LEVEL_INFO)
End Sub

Sub AStream_Error
	TileEvents.Insert($"[AStream_Error] "$, HMITileUtils.EVENT_LEVEL_ALARM)
End Sub

Sub AStream_Terminated
	TileEvents.Insert($"[AStream_Terminated] "$, HMITileUtils.EVENT_LEVEL_WARNING)
End Sub

Public Sub AStreamWrite(data() As Byte)
	Try
		AStream.Write(data)
		TileEvents.Insert($"[AStreamWrite] sending=${HMITileUtils.ByteConv.HexFromBytes(data)}"$, HMITileUtils.EVENT_LEVEL_INFO)
	Catch
		TileEvents.Insert($"[AStreamWrite] failed=${LastException}"$, HMITileUtils.EVENT_LEVEL_ALARM)
	End Try
End Sub
