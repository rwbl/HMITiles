﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=10.3
@EndOfDesignText@
#Region Class Header
' ================================================================
' File:     TileLogViewer.bas
' Brief:    Tile with a title, customlistview and trash icon (clear all log items).
'			
' Layout:
'+------------------+
'|      Label       |   
'|+----------------+|   
'||    Log Items   ||   
'||    Log Items   ||   
'|+----------------+|   
'+------------------+
' ================================================================
#End Region

' Designer Properties
#DesignerProperty: Key: TitleText, 	DisplayName: Title, FieldType: String, DefaultValue: Sensor
#DesignerProperty: Key: TimeStamp, 	DisplayName: Timestamp, FieldType: Boolean, DefaultValue: True, Description: Add timestamp 
#DesignerProperty: Key: MaxItems, DisplayName: Max Items, FieldType: Int, DefaultValue: 50, Description: Maximum number of log items.

' Events
#Event: Click(EventData As MouseEvent)

Sub Class_Globals
	' FX
	Private fx As JFX
	
	' Events
	Private mEventName As String	'ignore
	Private mCallBack As Object		'ignore

	' Base Views
	Public mBase As B4XView
	Public mLbl As B4XView
	Public Tag As Object

	' UI
	Private xui As XUI
	Private LabelTitle As B4XView
	Private ClvLog As CustomListView
	Private PaneLogViewer As B4XView
	Private LabelClear As B4XView
	
	' Properties
	Private mTimeStamp As Boolean
	Private mMaxItems As Int
End Sub

Public Sub Initialize (Callback As Object, EventName As String)
	mEventName = EventName
	mCallBack = Callback
End Sub

Public Sub DesignerCreateView (Base As Object, Lbl As Label, Props As Map)
	mBase = Base
	mLbl = Lbl
	Tag = mBase.Tag
	mBase.Tag = Me

	CallSubDelayed2(Me, "AfterLoadLayout", Props)
End Sub

Private Sub AfterLoadLayout(Props As Map)
	' First resize the base before loading the layout else customlistview not properly shown.
	Base_Resize(mBase.Width, mBase.Height)

	' Layout with label & clv
	mBase.LoadLayout("TileLogViewer")

	' Assign designer properties
	LabelTitle.Text = Props.Get("TitleText")
	mTimeStamp = Props.Get("TimeStamp")
	mMaxItems= Props.Get("MaxItems")

	' UI settings
	' For an ISA-101–compliant HMI, the clear-log icon is a non-process, non-critical UI action, 
	' so the color must follow the neutral control element rules.
	LabelClear.TextColor = TileUtils.COLOR_TEXT_SECONDARY

	' Set clv transparant
	ApplyStyle
End Sub

Private Sub Base_Resize(Width As Double, Height As Double)
	If Not(LabelTitle.IsInitialized) Or Not(ClvLog.IsInitialized) Then
		Return
	End If

	Dim pad As Int = TileUtils.TILE_BORDER_WIDTH + 4dip

	PaneLogViewer.SetLayoutAnimated(0, pad, pad, Width - pad * 2, Height - pad * 2)
	LabelTitle.SetLayoutAnimated(0, 0, 0, PaneLogViewer.Width, TileUtils.LOG_TITLE_HEIGHT)
	' LabelTitle.SetLayoutAnimated(0, 0, 0, PaneLogViewer.Width, PaneLogViewer.Height * titleheightfactor)
	' Not needed
	' ClvLog.sv.SetLayoutAnimated(0, 0, PaneLogViewer.Height * titleheightfactor, mBase.Width - 20, PaneLogViewer.Height * (1 - titleheightfactor) )
End Sub

' ========== Getters / Setters ==========

Public Sub setTitle(text As String)
	LabelTitle.Text = text
End Sub
Public Sub getTitle As String
	Return LabelTitle.Text
End Sub

Public Sub setTileColor(value As Int)
	mBase.Color = value
End Sub
Public Sub getTileColor As Int
	Return mBase.Color
End Sub

Public Sub setTextColor(value As Int)
	LabelTitle.TextColor = value
End Sub
Public Sub getTextColor As Int
	Return LabelTitle.TextColor
End Sub

Public Sub setEnabled(enabled As Boolean)
	mBase.Enabled = enabled
	If mBase.enabled Then
		mBase.Alpha = 1
	Else
		mBase.Alpha = 0.4
	End If
End Sub
Public Sub getEnabled As Boolean
	Return mBase.Enabled
End Sub

' Set number of max log items.
Public Sub setMaxItems(value As Int)
	mMaxItems = value
	' Remove only if needed
	Do While ClvLog.Size > mMaxItems
		ClvLog.RemoveAt(ClvLog.Size - 1) ' safely remove last (oldest) item
	Loop
End Sub
Public Sub getMaxItems As Int
	Return mMaxItems
End Sub

' ================================================================
' TILE STYLING
' ================================================================
#Region Tile Styling
Public Sub ApplyStyle

	LabelTitle.TextColor	= TileUtils.COLOR_TEXT_SECONDARY
	LabelTitle.TextSize 	= TileUtils.TEXT_SIZE_TITLE

	TileUtils.SetCLVBackgroundTransparent(ClvLog)

	mBase.SetColorAndBorder(TileUtils.COLOR_BACKGROUND_TILE_DEFAULT, _
							TileUtils.TILE_BORDER_WIDTH, _ 
							TileUtils.COLOR_STATE_ON_BORDER, _ 
							TileUtils.TILE_BORDER_RADIUS)
End Sub
#End Region

' ================================================================
' CLVLOG
' ================================================================
Private Sub ClvLog_ItemClick (Index As Int, Value As Object)
	Log($"[${mEventName}] index=${Index}, value=${Value}"$)
End Sub

' Insert new log item at first position:
' Newest on top, Most relevant information visible without scrolling.
' This is aligned with industrial HMI practice.
Public Sub Insert(item As String, level As Int)
	ClvLog.InsertAt(0, _
					ClvLogCreateItem(item, level), _
			        item)
	If ClvLog.Size > mMaxItems Then
		ClvLog.RemoveAt(ClvLog.Size - 1)
	End If
	Log($"[ClvLog.Insert] item=${item}, level=${level}"$)
End Sub

' Add new log item at last position and scroll.
' Not recommended.
Public Sub Add(item As String, level As Int)
	ClvLog.Add(ClvLogCreateItem(item, level), _
			   item)
	If ClvLog.Size > mMaxItems Then
		ClvLog.RemoveAt(0)
	End If
	ClvLog.JumpToItem(ClvLog.Size - 1)
	Log($"[ClvLog.Add] item=${item}, level=${level}"$)
End Sub

' Create logentry item.
Private Sub ClvLogCreateItem(item As String, level As Int) As Pane

	Dim pnl As B4XView = xui.CreatePanel("")
	pnl.SetLayoutAnimated(0, TileUtils.LOG_ITEM_PADDING, TileUtils.LOG_ITEM_PADDING, ClvLog.AsView.Width - (TileUtils.LOG_ITEM_PADDING * 2), TileUtils.LOG_ITEM_HEIGHT)

	Dim bgColor As Int = TileUtils.LOG_COLOR_INFO_BG
	Dim txtColor As Int = TileUtils.LOG_COLOR_INFO_TEXT
	
	Select level
		Case TileUtils.TILE_STATE_NORMAL         ' Info
			bgColor = TileUtils.LOG_COLOR_INFO_BG
			txtColor = TileUtils.LOG_COLOR_INFO_TEXT
	
		Case TileUtils.TILE_STATE_WARNING        ' Warning / Amber
			bgColor = TileUtils.LOG_COLOR_WARNING_BG
			txtColor = TileUtils.LOG_COLOR_WARNING_TEXT
	
		Case TileUtils.TILE_STATE_ALARM          ' Alarm / Red
			bgColor = TileUtils.LOG_COLOR_ALARM_BG
			txtColor = TileUtils.LOG_COLOR_ALARM_TEXT
	
		Case TileUtils.TILE_STATE_DISABLED       ' Disabled
			bgColor = TileUtils.LOG_COLOR_DISABLED_BG
			txtColor = TileUtils.LOG_COLOR_DISABLED_TEXT
	End Select
	pnl.Color = bgColor

	Dim lbl As B4XView = XUIViewsUtils.CreateLabel
	If mTimeStamp Then
		item = $"${FormatTimestamp(DateTime.Now)} - ${item}"$
	End If
	lbl.Text = item
	lbl.SetTextAlignment("CENTER", "LEFT")
	lbl.Font = xui.CreateDefaultFont(TileUtils.LOG_TEXT_SIZE_MESSAGE)
	lbl.TextColor = txtColor
	pnl.AddView(lbl, 0, 0, pnl.Width, pnl.Height)
	Return pnl
End Sub
#End Region

' Clear log items.
Public Sub Clear
	ClvLog.Clear
	Log($"[ClvLog.Clear] Done"$)
End Sub

' Clear all log entries
Private Sub LabelClear_MouseClicked (EventData As MouseEvent)
	ClvLog.Clear
End Sub

Private Sub FormatTimestamp(ts As Long) As String
	Return DateTime.Time(ts)
End Sub
