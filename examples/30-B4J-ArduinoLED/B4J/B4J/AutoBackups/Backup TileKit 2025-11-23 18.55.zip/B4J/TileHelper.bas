﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10.3
@EndOfDesignText@
#Region Class Header
' ================================================================
' File: 	TileHelper.bas
' Brief:	Common helper subs used by the customview tiles.
' ================================================================
#End Region

Sub Process_Globals
	' Private fx As JFX
	Public ByteConv As ByteConverter
End Sub

'=============================================================================
' TILE HELPER
'=============================================================================
Public Sub SetStyleBold(node As Node, value As Boolean)
	If value Then
		CSSUtils.SetStyleProperty(node, "-fx-font-weight", "bold")
	Else
		CSSUtils.SetStyleProperty(node, "-fx-font-weight", "normal")
	End If
End Sub
Public Sub GetStyleBold(node As Node) As Boolean
	Dim property As String = CSSUtils.GetStyleProperty(node, "-fx-font-weight")
	Return property == "bold"
End Sub

'Convert a color hex string to int.
'The hex string must be 8. If length 6 then FF is set as prefix.
Public Sub HexToColor(hex As String) As Int	'ignore
	Dim bc As ByteConverter
	If hex.StartsWith("#") Then
		hex = hex.SubString(1)
	Else If hex.StartsWith("0x") Then
		hex = hex.SubString(2)
	End If
	If hex.Length == 6 Then hex = $"FF${hex}"$
	Dim b() As Byte = bc.HexToBytes(hex)
	Dim ints() As Int = bc.IntsFromBytes(b)
	Return ints(0)
End Sub

Public Sub CopyLabelProps(src As B4XView, dest As B4XView) As B4XView
	dest.Text = src.Text
	dest.Font = src.Font
	dest.Color = src.Color
	dest.TextColor = src.TextColor
	dest.TextSize = src.TextSize
	Return dest
End Sub

' Call like: ChangeButtonTextAnimated(TileButton1, newText)
Public Sub ChangeButtonTextAnimated(target As B4XView, newText As String)
	Dim duration As Int = 240
	' Fade out
	target.SetAlphaAnimated(duration, 0) ' duration in ms, alpha 0 = invisible
	Sleep(120)
	' Change text
	target.Text = newText
	' Fade back in
	target.SetAlphaAnimated(duration, 1) ' alpha 1 = fully visible
End Sub


