﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=10.3
@EndOfDesignText@
' ================================================================
' B4XSeekBarEx
' Custom SeekBar with optional tickmarks (horizontal/vertical)
' Based upon the B4XSeekbar.
' Supports:
'   - Color1: track left/back
'   - Color2: track right/front
'   - ThumbColor
'   - Tick marks with labels
'   - Horizontal and vertical layouts
'   - Interval stepping
' ================================================================

#DesignerProperty: Key: Color1, DisplayName: Color 1, FieldType: Color, DefaultValue: 0xFF006AFF
#DesignerProperty: Key: Color2, DisplayName: Color 2, FieldType: Color, DefaultValue: 0xFF8AB9FC
#DesignerProperty: Key: ThumbColor, DisplayName: Thumb Color, FieldType: Color, DefaultValue: 0x58006AFF
#DesignerProperty: Key: TickValColor, DisplayName: Tick Value Color, FieldType: Color, DefaultValue: 0xFF1E1E1E
#DesignerProperty: Key: Interval, DisplayName: Interval, FieldType: Int, DefaultValue: 1
#DesignerProperty: Key: Min, DisplayName: Minimum, FieldType: Int, DefaultValue: 0
#DesignerProperty: Key: Max, DisplayName: Maximum, FieldType: Int, DefaultValue: 100
#DesignerProperty: Key: Value, DisplayName: Value, FieldType: Int, DefaultValue: 50
#Event: ValueChanged (Value As Int)
#Event: TouchStateChanged (Pressed As Boolean)

Sub Class_Globals
	Private mEventName As String
	Private mCallBack As Object
	Public mBase As B4XView
	Private xui As XUI

	' Colors
	Public Color1, Color2, ThumbColor, TickValColor As Int

	' Canvas
	Private cvs As B4XCanvas

	' Touch
	Private TouchPanel As B4XView
	Private Pressed As Boolean

	' Values
	Private mValue As Int
	Public MinValue, MaxValue As Int
	Public Interval As Int = 1

	' Sizes
	' ISA-101 Guidance
	' 6dip/3dip gives clean contrast without visual weight.
	' 8dip thumb Is safer For touch HMIs.
	' 18dip Pressed gives clear feedback without being too large.
	Public Radius1 As Int = 8dip     ' thumb size
	Public Radius2 As Int = 18dip    ' pressed thumb
	Public Size1 As Int = 6dip       ' active track
	Public Size2 As Int = 3dip       ' inactive track

	' Layout
	Private Vertical As Boolean
	Private size As Int

	' Tickmarks
	Public ShowTicks As Boolean = True
	Public TickCount As Int = 5 ' Min, 25%, 50%, 75%, Max
End Sub

' ------------------------------------------------
Public Sub Initialize(Callback As Object, EventName As String)
	mEventName = EventName
	mCallBack = Callback
End Sub

' ------------------------------------------------
Public Sub DesignerCreateView(Base As Object, Lbl As Label, Props As Map)
	mBase = Base
	mBase.Tag = Me
	Color1 = xui.PaintOrColorToColor(Props.Get("Color1"))
	Color2 = xui.PaintOrColorToColor(Props.Get("Color2"))
	ThumbColor = xui.PaintOrColorToColor(Props.Get("ThumbColor"))
	TickValColor = xui.PaintOrColorToColor(Props.Get("TickValColor"))
	Interval = Max(1, Props.GetDefault("Interval", 1))
	MinValue = Props.Get("Min")
	MaxValue = Props.Get("Max")
	mValue = Max(MinValue, Min(MaxValue, Props.Get("Value")))

	cvs.Initialize(mBase)

	TouchPanel = xui.CreatePanel("TouchPanel")
	mBase.AddView(TouchPanel, 0, 0, mBase.Width, mBase.Height)

	If xui.IsB4A Then Radius2 = 20dip
	Base_Resize(mBase.Width, mBase.Height)
End Sub

' ------------------------------------------------
Public Sub Base_Resize(Width As Double, Height As Double)
	cvs.Resize(Width, Height)
	TouchPanel.SetLayoutAnimated(0, 0, 0, Width, Height)
	Vertical = mBase.Height > mBase.Width
	size = Max(mBase.Height, mBase.Width) - 2 * Radius2
	Update
End Sub

' ------------------------------------------------
' Redraws slider and tickmarks
Public Sub Update
	cvs.ClearRect(cvs.TargetRect)

	If size <= 0 Then Return

	If Vertical = False Then ' Horizontal
		Dim y As Int = mBase.Height / 2
		Dim s1 As Int = Radius2 + (mValue - MinValue) / (MaxValue - MinValue) * size

		' Draw left/back track
		cvs.DrawLine(Radius2, y, s1, y, Color1, Size1)
		' Draw right/front track
		cvs.DrawLine(s1, y, mBase.Width - Radius2, y, Color2, Size2)
		' Draw thumb
		cvs.DrawCircle(s1, y, Radius1, Color1, True, 0)
		If Pressed Then cvs.DrawCircle(s1, y, Radius2, ThumbColor, True, 0)

		' Draw tickmarks if enabled
		If ShowTicks And TickCount > 1 Then
			For i = 0 To TickCount - 1
				Dim xTick As Float = Radius2 + i * size / (TickCount - 1)
				' Tick line
				cvs.DrawLine(xTick, y - 6dip, xTick, y + 6dip, Color1, 1dip)
				' Tick label below tick
				Dim tickVal As Int = MinValue + i * (MaxValue - MinValue) / (TickCount - 1)
				cvs.DrawText(tickVal, xTick, y + 16dip + 6dip, xui.CreateDefaultFont(12), TickValColor, "CENTER")
			Next
		End If
	Else ' Vertical
		Dim x As Int = mBase.Width / 2
		Dim s1 As Int = Radius2 + (MaxValue - mValue) / (MaxValue - MinValue) * size

		' Draw bottom/back track
		cvs.DrawLine(x, Radius2, x, s1, Color2, Size2)
		' Draw top/front track
		cvs.DrawLine(x, s1, x, mBase.Height - Radius2, Color1, Size1)
		' Draw thumb
		cvs.DrawCircle(x, s1, Radius1, Color1, True, 0)
		If Pressed Then cvs.DrawCircle(x, s1, Radius2, ThumbColor, True, 0)

		' Draw tickmarks if enabled
		If ShowTicks And TickCount > 1 Then
			For i = 0 To TickCount - 1
				Dim yTick As Float = Radius2 + i * size / (TickCount - 1)
				' Tick line
				cvs.DrawLine(x - 6dip, yTick, x + 6dip, yTick, Color1, 1dip)
				' Tick label left of tick
				Dim tickVal As Int = MaxValue - i * (MaxValue - MinValue) / (TickCount - 1)
				cvs.DrawText(tickVal, x - 6dip - 6dip, yTick + 4dip, xui.CreateDefaultFont(12), TickValColor, "RIGHT")
			Next
		End If
	End If

	cvs.Invalidate
End Sub

' ------------------------------------------------
Private Sub TouchPanel_Touch(Action As Int, X As Float, Y As Float)
	If Action = TouchPanel.TOUCH_ACTION_DOWN Then
		Pressed = True
		RaiseTouchStateEvent
		SetValueBasedOnTouch(X, Y)
	Else If Action = TouchPanel.TOUCH_ACTION_MOVE Then
		SetValueBasedOnTouch(X, Y)
	Else If Action = TouchPanel.TOUCH_ACTION_UP Then
		Pressed = False
		RaiseTouchStateEvent
	End If
	Update
End Sub

Private Sub RaiseTouchStateEvent
	If xui.SubExists(mCallBack, mEventName & "_TouchStateChanged", 1) Then
		CallSubDelayed2(mCallBack, mEventName & "_TouchStateChanged", Pressed)
	End If
End Sub

Private Sub SetValueBasedOnTouch(x As Int, y As Int)
	Dim v As Int
	If Vertical Then
		v = (mBase.Height - Radius2 - y) / size * (MaxValue - MinValue) + MinValue
	Else
		v = (x - Radius2) / size * (MaxValue - MinValue) + MinValue
	End If
	v = Round(v / Interval) * Interval
	Dim NewValue As Int = Max(MinValue, Min(MaxValue, v))
	If NewValue <> mValue Then
		mValue = NewValue
		If xui.SubExists(mCallBack, mEventName & "_ValueChanged", 1) Then
			CallSubDelayed2(mCallBack, mEventName & "_ValueChanged", mValue)
		End If
	End If
End Sub

' ------------------------------------------------
' Setter/Getter
' ------------------------------------------------
Public Sub setValue(v As Int)
	mValue = Max(MinValue, Min(MaxValue, v))
	Update
End Sub

Public Sub getValue As Int
	Return mValue
End Sub
