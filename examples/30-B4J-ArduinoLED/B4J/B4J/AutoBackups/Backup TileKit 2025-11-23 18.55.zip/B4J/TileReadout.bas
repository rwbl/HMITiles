﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=10.3
@EndOfDesignText@
#Region Class Header
' ================================================================
' File:     TileReadout.bas
' Brief:    Tile with a title and a big value+unit readout.
'           Supports Normal, Warning, Alarm, Dimmed styles.
' Layout:
'+------------------+
'|      Label       |   <- center, font size 15
'|       23         |   <- large, font size 2x label
'|       °C         |   <- small, font size 0.5–0.7x value
'+------------------+
' ================================================================
#End Region

' Designer Properties
#DesignerProperty: Key: TitleText, 	DisplayName: Title, FieldType: String, DefaultValue: Sensor
#DesignerProperty: Key: ValueText, 	DisplayName: Value, FieldType: String, DefaultValue: --
#DesignerProperty: Key: ValueScale, DisplayName: Value Text Scale, FieldType: Float, DefaultValue: 2.0
#DesignerProperty: Key: UnitText, 	DisplayName: Unit, FieldType: String, DefaultValue: Unit
#DesignerProperty: Key: UnitScale,	DisplayName: Unit Text Scale, FieldType: Float, DefaultValue: 0.8
#DesignerProperty: Key: TypeStyle,	DisplayName: Tile Style, FieldType: String, List: Normal|Warning|Alarm|Dimmed, DefaultValue: Normal

' Events
#Event: Click(EventData As MouseEvent)

Sub Class_Globals
	' Events
	Private mEventName As String
	Private mCallBack As Object

	' Base Views
	Public mBase As B4XView
	Public mLbl As B4XView
	Public Tag As Object

	' UI
	Private xui As XUI
	Private LabelTitle As B4XView
	Private LabelValue As B4XView
	Private LabelUnit As B4XView
End Sub

Public Sub Initialize (Callback As Object, EventName As String)
	mEventName = EventName
	mCallBack = Callback
End Sub

Public Sub DesignerCreateView (Base As Object, Lbl As Label, Props As Map)
	mBase = Base
	mLbl = Lbl
	Tag = mBase.Tag
	mBase.Tag = Me

	CallSubDelayed2(Me, "AfterLoadLayout", Props)
End Sub

Private Sub AfterLoadLayout(Props As Map)	'ignore
	mBase.LoadLayout("TileReadout")

	LabelTitle.Text = Props.Get("TitleText")
	LabelValue.Text = Props.Get("ValueText")
	LabelUnit.Text = Props.Get("UnitText")

	ApplyStyle(Props.Get("TypeStyle"))

	Base_Resize(mBase.Width, mBase.Height)
End Sub

Private Sub Base_Resize(Width As Double, Height As Double)
	If Not(LabelTitle.IsInitialized) Or Not(LabelValue.IsInitialized) Then Return

	Dim pad As Int = TileUtils.TILE_BORDER_WIDTH + 4dip
	
	LabelTitle.SetLayoutAnimated(0, pad, pad, Width - pad*2, Height * 0.25)
	LabelValue.SetLayoutAnimated(0, pad, Height*0.25, Width - pad*2, Height*0.60)
	LabelUnit.SetLayoutAnimated(0, pad, Height*0.80, Width - pad*2, Height*0.15)
End Sub

' ========== Getters / Setters ==========

Public Sub setTitle(text As String)
	LabelTitle.Text = text
End Sub
Public Sub getTitle As String
	Return LabelTitle.Text
End Sub

Public Sub setValue(value As String)
	LabelValue.Text = value
End Sub
Public Sub getValue As String
	Return LabelValue.Text
End Sub

Public Sub setTileColor(value As Int)
	mBase.Color = value
End Sub
Public Sub getTileColor As Int
	Return mBase.Color
End Sub

Public Sub setTextColor(value As Int)
	LabelTitle.TextColor = value
	LabelValue.TextColor = value
End Sub
Public Sub getTextColor As Int
	Return LabelTitle.TextColor
End Sub

Public Sub setEnabled(enabled As Boolean)
	mBase.Enabled = enabled
	If mBase.enabled Then
		mBase.Alpha = 1
	Else
		mBase.Alpha = 0.4
	End If
End Sub
Public Sub getEnabled As Boolean
	Return mBase.Enabled
End Sub

Public Sub SetStateColor(success As Boolean)
	TileUtils.ApplyStyleStateOnOff(mBase, LabelValue, success)
End Sub

Private Sub LabelValue_MouseClicked (EventData As MouseEvent)
	' Log($"[TileReadOut] LabelValue_MouseClicked mcallback=${mCallback}, meventname=${meventname}"$)
	If SubExists(mCallBack, mEventName & "_Click") Then
		CallSub2(mCallBack, mEventName & "_Click", EventData)
	End If
End Sub

' ================================================================
' TILE STYLING
' ================================================================
#Region Tile Styling
Public Sub ApplyStyle(tilestate As String)
	LabelTitle.TextColor	= TileUtils.COLOR_TEXT_SECONDARY
	LabelTitle.TextSize 	= TileUtils.TEXT_SIZE_TITLE
	LabelUnit.TextColor 	= TileUtils.COLOR_TEXT_SECONDARY
	LabelUnit.TextSize 		= TileUtils.TEXT_SIZE_SMALL

	Dim state As Int = TileUtils.StateStyleToState(tilestate)
	Select state
		Case TileUtils.TILE_STATE_NORMAL
			LabelValue.TextSize = TileUtils.TEXT_SIZE_LABEL
			LabelValue.TextColor = TileUtils.TILE_COLOR_NORMAL_TEXT
			mBase.Color = TileUtils.TILE_COLOR_NORMAL_BACKGROUND

		Case TileUtils.TILE_STATE_WARNING
			LabelValue.TextSize = TileUtils.TEXT_SIZE_LABEL
			LabelValue.TextColor = TileUtils.TILE_COLOR_WARNING_TEXT
			mBase.Color = TileUtils.TILE_COLOR_WARNING_BACKGROUND

		Case TileUtils.TILE_STATE_ALARM
			LabelValue.TextSize = TileUtils.TEXT_SIZE_LABEL
			LabelValue.TextColor = TileUtils.TILE_COLOR_ALARM_TEXT
			mBase.Color = TileUtils.TILE_COLOR_ALARM_BACKGROUND

		Case TileUtils.TILE_STATE_DISABLED
			LabelValue.TextSize = TileUtils.TEXT_SIZE_LABEL
			LabelValue.TextColor = TileUtils.TILE_COLOR_DISABLED_TEXT
			mBase.Color = TileUtils.TILE_COLOR_DISABLED_BACKGROUND
	End Select
	
	mBase.SetColorAndBorder(TileUtils.COLOR_BACKGROUND_TILE_DEFAULT, _ 
							TileUtils.TILE_BORDER_WIDTH, _ 
							TileUtils.COLOR_STATE_ON_BORDER, _ 
							TileUtils.TILE_BORDER_RADIUS)
End Sub
#End Region
