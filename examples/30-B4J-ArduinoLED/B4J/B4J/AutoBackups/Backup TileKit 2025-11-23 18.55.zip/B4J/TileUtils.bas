﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10.3
@EndOfDesignText@
#Region Class Header
' ================================================================
' File: 	TileUtils.bas
' Brief:	Common constants and helper subs used by the customview tiles.
'			Central styling module for HK32HMI following ISA-101 standards.
'     			- Base colors (neutral grayscale)
'     			- Alarm colors (amber/red)
'     			- Text colors & sizes
'     			- Tile background/text colors per state
'     			- ApplyTileStyle() method that styles a tile dynamically
' Note:		Colors info, warning, and error/alarm ISA-101 conventions:
'				-Info → Neutral. No color.
'				- Warning → Amber (one specific ISA yellow)
'				- Error/Alarm → Red (one specific ISA red)
'				| State       | Background      | Text       | Notes         |
'				| ----------- | --------------- | ---------- | ------------- |
'				| **INFO**    | Neutral gray    | Light gray | No color      |
'				| **WARNING** | Amber (#FFD24C) | Black      | Soft contrast |
'				| **ERROR**   | Red (#D32F2F)   | White      | High contrast |
'
'				| Tile Type      | Width x Height (dp) | Notes                                                              |
'				| -------------- | ------------------- | ------------------------------------------------------------------ |
'				| **TileLabel**  | 100 x 60            | Single text, no state line; small info tile                        |
'				| **TileSensor** | 120 x 80            | Two lines: title + value; extra padding For numeric sensor display |
'				| **TileButton** | 120 x 80            | Two lines: title + state; touch-friendly                           |
'				| **TileToggle** | 120 x 80            | Two lines: title + ON/OFF state; border indicates toggle           |
'				| **TileLarge**  | 200 x 120           | Important display: alarms, Main sensor, Main button                |
'				| **TileWide**   | 200 x 80            | Wide layout For long titles Or sliders                             |
'				| **TileSmall**  | 80 x 50             | Secondary info Or indicators (LED-style)                           |
'
' Author: 	Robert W.B. Linn (c) 2025 MIT
' ================================================================
#End Region

Sub Process_Globals
	' XUI/FX
	Private xui As XUI
	Private fx As JFX

	' Tile Grid Helper
	Private TileGrid As TileGridHelper
	
	' ================================================================
	' HMI Colors (ISA-101)
	' ================================================================
	' ================================================================
	' ISA-101 LIGHT THEME COLOR SET (Corrected)
	' ================================================================

	' ================================================================
	' BACKGROUND COLORS (True ISA-101 Neutral Grays)
	' ================================================================
	Public Const COLOR_BACKGROUND_SCREEN        As Int = 0xFFE6E6E6   ' very light neutral gray
	Public Const COLOR_BACKGROUND_PANEL         As Int = 0xFFCCCCCC   ' panel slightly darker
	Public Const COLOR_BACKGROUND_TILE_DEFAULT  As Int = 0xFFB0B0B0   ' medium gray tile background
	Public Const COLOR_BACKGROUND_TILE_HOVER    As Int = 0xFFBBBBBB   ' just a bit lighter on hover
	Public Const COLOR_BORDER_DEFAULT           As Int = 0xFF888888   ' dark neutral border

	' ================================================================
	' STATUS COLORS (ALARM ONLY)
	' ================================================================
	Public Const COLOR_STATUS_WARNING           As Int = 0xFFFFD24C
	Public Const COLOR_STATUS_ALARM_LO          As Int = 0xFFFFA000
	Public Const COLOR_STATUS_ALARM_HI          As Int = 0xFFD32F2F
	Public Const COLOR_STATUS_FORBIDDEN         As Int = 0xFF7F0000

	' ================================================================
	' TILE STATES (NORMAL ON/OFF)
	' ================================================================
	Public Const COLOR_STATE_OFF_BACKGROUND     As Int = 0xFFB0B0B0   ' same as default tile
	Public Const COLOR_STATE_ON_BACKGROUND      As Int = 0xFF8C8C8C   ' only slightly darker
	Public Const COLOR_STATE_OFF_BORDER         As Int = 0xFF888888
	Public Const COLOR_STATE_ON_BORDER          As Int = 0xFF666666
	Public Const COLOR_STATE_TEXT               As Int = 0xFF202020   ' dark text for readability

	' ================================================================
	' TEXT COLORS
	' ================================================================
	Public Const COLOR_TEXT_PRIMARY             As Int = 0xFF202020   ' almost black
	Public Const COLOR_TEXT_SECONDARY           As Int = 0xFF505050
	Public Const COLOR_TEXT_DISABLED            As Int = 0xFF7A7A7A
	Public Const COLOR_TEXT_WARNING             As Int = COLOR_STATUS_WARNING
	Public Const COLOR_TEXT_ERROR               As Int = COLOR_STATUS_ALARM_HI

	' ================================================================
	' TILE STATES
	' ================================================================
	Public Const TILE_STATE_NORMAL              As Int = 0
	Public Const TILE_STATE_WARNING             As Int = 1
	Public Const TILE_STATE_ALARM               As Int = 2
	Public Const TILE_STATE_DISABLED            As Int = 3

	' ================================================================
	' TILE COLORS PER STATE
	' ================================================================
	Public Const TILE_COLOR_NORMAL_BACKGROUND   As Int = COLOR_BACKGROUND_TILE_DEFAULT
	Public Const TILE_COLOR_NORMAL_TEXT         As Int = COLOR_TEXT_PRIMARY

	Public Const TILE_COLOR_WARNING_BACKGROUND  As Int = COLOR_STATUS_WARNING
	Public Const TILE_COLOR_WARNING_TEXT        As Int = 0xFF000000

	Public Const TILE_COLOR_ALARM_BACKGROUND    As Int = COLOR_STATUS_ALARM_HI
	Public Const TILE_COLOR_ALARM_TEXT          As Int = 0xFFFFFFFF

	Public Const TILE_COLOR_DISABLED_BACKGROUND As Int = 0xFFDDDDDD
	Public Const TILE_COLOR_DISABLED_TEXT       As Int = COLOR_TEXT_DISABLED

	' ================================================================
	' TILE BORDER
	' ================================================================
	Public Const TILE_BORDER_WIDTH              As Double = 1
	Public Const TILE_BORDER_RADIUS             As Double = 12

	' ================================================================
	' ISA-101 HMI Layout Grid Guidelines
	' ================================================================

	' 8-point baseline grid (8dip, 16dip, 24dip …)
	Public Const GRID_BASELINE              	As Double = 8
	' 16dip spacing between tiles
	Public Const TILE_SPACING              		As Double = 16
	' 32dip margins outer screen edge
	Public Const TILE_OUTER_SCREEN_EDGE			As Double = 32

	' Default padding
	Public Const TILE_PADDING As Int = 4dip

	' ================================================================
	' TEXT SIZES (SP) — ISA-101 Aligned
	' ================================================================

	' Titles (screen section headers, panel titles)
	Public Const TEXT_SIZE_TITLE        As Float = 18

	' Tile label (the top label inside a tile)
	Public Const TEXT_SIZE_LABEL        As Float = 16

	' Tile state/value text (the main content)
	Public Const TEXT_SIZE_STATE        As Float = 20

	' Small secondary text (units, small info)
	Public Const TEXT_SIZE_SMALL        As Float = 14

	' Tiny text (footnotes, timestamps)
	Public Const TEXT_SIZE_TINY         As Float = 12

	' Icon size (tile icon or symbol font)
	Public Const TEXT_SIZE_ICON         As Float = 32

	' ================================================================
	' LOG VIEWER (LV) — ISA-101 Aligned
	' ================================================================

	' INFO
	Public Const LOG_COLOR_INFO_BG        As Int = 0xFFF2F2F2
	Public Const LOG_COLOR_INFO_TEXT      As Int = 0xFF303030

	' WARNING (AMBER)
	Public Const LOG_COLOR_WARNING_BG     As Int = 0xFFF0A000
	Public Const LOG_COLOR_WARNING_TEXT   As Int = 0xFF000000   'black

	' ALARM (RED)
	Public Const LOG_COLOR_ALARM_BG       As Int = 0xFFB00020
	Public Const LOG_COLOR_ALARM_TEXT     As Int = 0xFFFFFFFF   'white

	' DISABLED
	Public Const LOG_COLOR_DISABLED_BG    As Int = 0xFFCCCCCC
	Public Const LOG_COLOR_DISABLED_TEXT  As Int = 0xFF555555
	
	Public Const LOG_LEVEL_INFO As Int = TILE_STATE_NORMAL
	Public Const LOG_LEVEL_WARNING As Int = TILE_STATE_WARNING            
	Public Const LOG_LEVEL_ALARM As Int = TILE_STATE_ALARM              

	' Log text sizes
	Public Const LOG_TEXT_SIZE_TIMESTAMP As Float	= 10
	Public Const LOG_TEXT_SIZE_MESSAGE As Float		= 11
	Public Const LOG_TEXT_SIZE_SOURCE As Float    	= 14
	Public Const LOG_TEXT_SIZE_ICON As Float      	= 20

	Public Const LOG_TITLE_HEIGHT As Int			= 32dip

	' Log Item Height
	' ISA-101 uses very tight Log spacing — no wasted space.
	' - item height from 24–28dip
	' - padding inside each row 4dip
	' This will show more Log lines per screen.
	Public Const LOG_ITEM_HEIGHT As Int				= 24dip
	Public Const LOG_ITEM_PADDING As Int			= 4dip

	' ================================================================
	' ISA-101 Slider Colors
	' ================================================================

	' --- Track (background / inactive area)
	Public Const COLOR_SLIDER_TRACK            As Int = 0xFFD6D6D6   ' Light neutral gray (#D6D6D6)

	' --- Active track (portion indicating the set value)
	Public Const COLOR_SLIDER_ACTIVE           As Int = 0xFF6A8FBF   ' Muted blue (#6A8FBF)

	' --- Slider knob (handle)
	Public Const COLOR_SLIDER_KNOB             As Int = 0xFF3F5A7F   ' Darker muted blue (#3F5A7F)

	' --- Disabled state track
	Public Const COLOR_SLIDER_DISABLED_TRACK   As Int = 0xFFBEBEBE   ' Mid-gray (#BEBEBE)

	' --- Disabled knob
	Public Const COLOR_SLIDER_DISABLED_KNOB    As Int = 0xFF9A9A9A   ' Slightly darker gray (#9A9A9A)

	' --- Value text color (live numeric value)
	Public Const COLOR_SLIDER_VALUE_TEXT       As Int = 0xFF2A2A2A   ' Very dark gray (#2A2A2A)

	' --- Label text color (caption / description)
	Public Const COLOR_SLIDER_LABEL_TEXT       As Int = 0xFF1E1E1E   ' Charcoal gray (#1E1E1E)

	' --- Units text color (optional)
	Public Const COLOR_SLIDER_UNIT_TEXT        As Int = 0xFF3A3A3A   ' Dark slightly lighter gray (#3A3A3A)

	' ================================================================
	' HELPERS
	' ================================================================
	' Byte converter - very useful
	Public ByteConv As ByteConverter
End Sub

' ================================================================
' TILE STYLING
' ================================================================
#Region Tile Styling
' ApplyTileTitleStyle
' For all tiles the title style are consistent
' Parameters:
'	view B4XView - Title label
Public Sub ApplyStyleTitle(tilepane As B4XView, titlelabel As B4XView, tilestate As String)
	titlelabel.TextColor = COLOR_TEXT_SECONDARY
	titlelabel.TextSize = TEXT_SIZE_TITLE

	Dim state As Int = StateStyleToState(tilestate)
	Select state
		Case TILE_STATE_NORMAL
			tilepane.Color = TILE_COLOR_NORMAL_BACKGROUND

		Case TILE_STATE_WARNING
			tilepane.Color = TILE_COLOR_WARNING_BACKGROUND

		Case TILE_STATE_ALARM
			tilepane.Color = TILE_COLOR_ALARM_BACKGROUND

		Case TILE_STATE_DISABLED
			tilepane.Color = TILE_COLOR_DISABLED_BACKGROUND
	End Select
	
	tilepane.SetColorAndBorder(tilepane.Color, TILE_BORDER_WIDTH, COLOR_STATE_ON_BORDER, TILE_BORDER_RADIUS)
End Sub
#End Region

Public Sub ApplyStyleStateOnOff(tilepane As B4XView, statelabel As B4XView, state As Boolean)
	If state Then
		tilepane.Color = COLOR_STATE_ON_BACKGROUND
		CSSUtils.SetBorder(tilepane, TILE_BORDER_WIDTH, ColorXUIToFX(COLOR_STATE_ON_BORDER), TILE_BORDER_RADIUS)
		statelabel.TextColor = COLOR_TEXT_PRIMARY
	Else
		tilepane.Color = COLOR_STATE_OFF_BACKGROUND
		CSSUtils.SetBorder(tilepane, TILE_BORDER_WIDTH, ColorXUIToFX(COLOR_STATE_OFF_BORDER), TILE_BORDER_RADIUS)
		statelabel.TextColor = COLOR_TEXT_SECONDARY
	End If
End Sub

' ================================================================
' Helper: Set default ISA-101 text sizes
' ================================================================
Public Sub ApplyTitleTextStyle(lbl As B4XView, Bold As Boolean)
    If lbl.IsInitialized Then
        lbl.TextSize = TEXT_SIZE_LABEL
        lbl.TextColor = COLOR_TEXT_PRIMARY
        If Bold Then 
			lbl.Font = xui.CreateDefaultBoldFont(lbl.TextSize)
End If
    End If
End Sub

Public Sub ApplyValueTextStyle(lbl As B4XView)
    If lbl.IsInitialized Then
        lbl.TextSize = TEXT_SIZE_TITLE
        lbl.TextColor = COLOR_TEXT_PRIMARY
    End If
End Sub

Public Sub SetStyleBold(node As Node, value As Boolean)
	If value Then
		CSSUtils.SetStyleProperty(node, "-fx-font-weight", "bold")
	Else
		CSSUtils.SetStyleProperty(node, "-fx-font-weight", "normal")
	End If
End Sub

Public Sub GetStyleBold(node As Node) As Boolean
	Dim property As String = CSSUtils.GetStyleProperty(node, "-fx-font-weight")
	Return property == "bold"
End Sub

Public Sub GetStyleBorderRadius(node As Node) As Double
	Dim s As String = CSSUtils.GetStyleProperty(node, "-fx-border-radius")
	If s.Length == 0 Then
		Return TILE_BORDER_RADIUS
	Else
		Return s
	End If
End Sub

'
' Conversions

'Convert a color hex string to int.
'The hex string must be 8. If length 6 then FF is set as prefix.
Public Sub HexToColor(hex As String) As Int	'ignore
	Dim bc As ByteConverter
	If hex.StartsWith("#") Then
		hex = hex.SubString(1)
	Else If hex.StartsWith("0x") Then
		hex = hex.SubString(2)
	End If
	If hex.Length == 6 Then hex = $"FF${hex}"$
	Dim b() As Byte = bc.HexToBytes(hex)
	Dim ints() As Int = bc.IntsFromBytes(b)
	Return ints(0)
End Sub

Public Sub ColorToHexARGB(clr As Int) As String
	Dim bc As ByteConverter
	Return bc.HexFromBytes(bc.IntsToBytes(Array As Int(clr)))
End Sub

Public Sub ColorToHexRGB(clr As Int) As String
	Dim bc As ByteConverter
	Dim hex As String = bc.HexFromBytes(bc.IntsToBytes(Array As Int(clr)))
	Return hex.SubString2(2, hex.Length)
End Sub

Public Sub ColorXUIToFX(value As Int) As Paint
	Return fx.Colors.From32Bit(xui.Color_White)
End Sub

' ================================================================
' Helper: Set text color safely (null-safe)
' ================================================================
Public Sub SetTextColor(lbl As B4XView, col As Int)
	If lbl.IsInitialized Then lbl.TextColor = col
End Sub

Public Sub CopyLabelProps(src As B4XView, dest As B4XView) As B4XView
	dest.Text = src.Text
	dest.Font = src.Font
	dest.Color = src.Color
	dest.TextColor = src.TextColor
	dest.TextSize = src.TextSize
	Return dest
End Sub

' Call like: ChangeButtonTextAnimated(TileButton1, newText)
Public Sub ChangeButtonTextAnimated(target As B4XView, newText As String)
	Dim duration As Int = 240
	' Fade out
	target.SetAlphaAnimated(duration, 0) ' duration in ms, alpha 0 = invisible
	Sleep(120)
	' Change text
	target.Text = newText
	' Fade back in
	target.SetAlphaAnimated(duration, 1) ' alpha 1 = fully visible
End Sub

Public Sub StateStyleToState(state As String) As Int
	Dim result As Int
	Select state
		Case "Normal"
			result = TILE_STATE_NORMAL
		Case "Warning"
			result = TILE_STATE_WARNING
		Case "Error"
			result = TILE_STATE_ALARM
		Case "Alarm"
			result = TILE_STATE_ALARM
		Case "Dimmed"
			result = TILE_STATE_DISABLED
		Case Else
			result = TILE_STATE_NORMAL
	End Select
	Return result
End Sub

' Set CLV background transparent
' Example:
' SetCLVBackgroundTransparent(ClvCommands)
Public Sub SetCLVBackgroundTransparent(clv As CustomListView)
	Dim sp As ScrollPane = clv.sv
	CSSUtils.SetStyleProperty(sp, "-fx-background", "transparent")
	CSSUtils.SetStyleProperty(sp, "-fx-background-color", "transparent")
	
	' This targets the internal viewport (the gray area inside)
	CSSUtils.SetStyleProperty(sp, "-fx-control-inner-background", "transparent")
	CSSUtils.SetStyleProperty(sp, "-fx-control-inner-background-alt", "transparent")

End Sub

#Region TileGrid
' ================================================================
' Tile Grid -PLANNED
' ================================================================
' Implementation details & safety notes
' - Canvas isolation: Grid uses its own B4XCanvas And gridPanel. Tiles that also use B4XCanvas draw into their own panel Or mBase. Since gridPanel.SendToBack Is used, the grid Is always behind other views And doesn’t intercept touches.
' - Performance: The drawing Is simple lines; even on large screens it Is cheap. Call Redraw only when settings change Or on resize.
' - Design vs runtime: You can leave the grid toggled off For runtime And use it only during development Or layout tuning.
' - Coordinate system: grid draws in device-independent dips (B4X uses dips), matching your tile sizes.
' - Customization: Expose MinorStep, MajorStep, MinorColor, MajorColor, And ShowCoordinates from TileUtils (Or set them directly on TileGridHelper) If you want a single place To tune visual rules.

Public Sub EnableTileGrid(parent As B4XView)
	If Not(TileGrid.IsInitialized) Then
		TileGrid.Initialize(parent)		
	End If
	TileGrid.Resize
	TileGrid.ShowGrid = True
	TileGrid.Redraw
End Sub

Public Sub DisableTileGrid
	If Not(TileGrid.IsInitialized) Then
		Return
	End If
	TileGrid.ShowGrid = False
	TileGrid.Redraw
End Sub

' ================================================================
' Snap a single coordinate to the nearest grid
' ================================================================
Public Sub SnapCoord(value As Int) As Int
	If Not(TileGrid.IsInitialized) Then
		Return 0
	End If
	Dim stepSize As Int = TileGrid.MinorStep
	If stepSize <= 0 Then stepSize = 8dip
	Return Round(value / stepSize) * stepSize
End Sub

' ================================================================
' Snap X,Y position of a tile to the grid
' ================================================================
Public Sub SnapViewToGrid(v As B4XView)
	If v.IsInitialized = False Then Return
	v.Left = SnapCoord(v.Left)
	v.Top = SnapCoord(v.Top)
End Sub

' ================================================================
' Snap Width/Height (optional)
' ================================================================
Public Sub SnapSizeToGrid(v As B4XView)
	If v.IsInitialized = False Then Return
	v.Width = SnapCoord(v.Width)
	v.Height = SnapCoord(v.Height)
End Sub

' ================================================================
' Snap full bounding box (position + size)
' ================================================================
Public Sub SnapViewFull(v As B4XView)
	SnapViewToGrid(v)
	SnapSizeToGrid(v)
End Sub

Public Sub SnapAllChildrenToGrid(parent As B4XView)
	For Each c As B4XView In parent.GetAllViewsRecursive
		SnapViewToGrid(c)
	Next
End Sub

'Test Private Sub B4XPage_Created (Root1 As B4XView):
'	TileUtils.EnableTileGrid(Root)
'	Sleep(1)
'	TileUtils.SnapAllChildrenToGrid(Root)
'	Sleep(1)
'	TileUtils.DisableTileGrid
'	Sleep(1)

#End Region