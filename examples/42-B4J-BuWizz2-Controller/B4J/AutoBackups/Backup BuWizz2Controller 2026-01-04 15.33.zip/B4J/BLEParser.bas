﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=StaticCode
Version=10.3
@EndOfDesignText@
#Region Class Header
' Class:        BLEParser
' Brief:        Parse BLE messages.
' Date:         2025-11-30
' Author:       Robert W.B. Linn (c) 2025 MIT
' Description:  Parse received BLE payload and store as a map.
#End Region

Private Sub Process_Globals
'
End Sub

#Region Parse
' Parse
' Parse the BLE message by selecting the device.
' Parameters:
'	data Byte Array - BLE payload
' Returns:
'	n/a
Public Sub Parse(data() As Byte)
	If data.Length < 2 Then
		Log($"[BLEParser.Parse] E: Message too short."$)
		Return
	End If
	Log($"[BLEParser.Parse] data=${Convert.HexFromBytes(data)}"$)
End Sub
#End Region

