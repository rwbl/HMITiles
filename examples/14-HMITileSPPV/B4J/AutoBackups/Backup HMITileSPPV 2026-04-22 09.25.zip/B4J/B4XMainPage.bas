﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=9.85
@EndOfDesignText@
' ================================================================
' File:			HMITileSPPV
' Project:		HMITiles B4X library
' Brief:		Get started with HMITileSPPV
' Description:	Shows several SPPV.
' Date:			2026-04-22
' Author:		Robert W.B. Linn (c) 2026 MIT
' ================================================================

Sub Class_Globals
	' UI	
	Private xui As XUI
	Private Root As B4XView
	Private LabelLegend As B4XView
	Private TileSPPV1 As HMITileSPPV
	Private TileSPPV2 As HMITileSPPV
End Sub

Public Sub Initialize
	B4XPages.GetManager.LogEvents = True
End Sub

Private Sub B4XPage_Created (Root1 As B4XView)
	Root = Root1
	Root.LoadLayout("mainpage")
	B4XPages.SetTitle(Me, "HMITileSPPV")
	
	LabelLegend.Text = $"HMITiles Get Started${CRLF}Recommended tile size: 120x120px. Tile color Yellow=Warning, Red=Alarm."$
	
	' ===================================================
	' HMITiles
	' ===================================================
	' Sleep must be set to enable customviews load designer layouts
	Sleep(1)
	' Make any HMITile property changes here
	TileSPPVsSetProperties
End Sub

' ================================================================
' PROPERTIES
' ================================================================

Private Sub TileSPPVsSetProperties
	TileSPPV1.PV = 70

'	TileSPPV1.DeviationLimit = 10
'	TileSPPV1.SP = 25
'	TileSPPV1.PV = 20
'	TileSPPV1.StepSize = 5
'	TileSPPV1.ShowDeviation = True
'	TileSPPV1.EditMode = True
End Sub


' ===================================================
' EVENTS
' ===================================================

Private Sub TileSPPV1_ValueChanged (Value As Float)
	Log($"[TileSPPV1_ValueChanged] value=${Value}"$)
End Sub

Private Sub TileSPPV1_SetPointChanged (Value As Float)
	Log($"[TileSPPV1_SetPointChanged] value=${Value}"$)
End Sub

Private Sub TileSPPV2_ValueChanged (Value As Float)
	Log($"[TileSPPV2_ValueChanged] value=${Value}"$)
End Sub

Private Sub TileSPPV2_SetPointChanged (Value As Float)
	Log($"[TileSPPV2_SetPointChanged] value=${Value}"$)
End Sub

